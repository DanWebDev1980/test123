console.log("HDAutomation StaticScriptStartMTA injected!");

window.StaticScriptStartMTA = function (jwt, policyNumber) {
  console.log("window.StaticScriptStartMTA - jwt: ", jwt);
  console.log("window.StaticScriptStartMTA - policyNumber: ", policyNumber);
  window.startMtaJourney(
    JSON.stringify({
      accessToken: jwt,
      policyNumber: policyNumber,
      cid: "sjdsd4jsdhfjkf-dfkjgn45",
      source: "ios",
    })
  );
};

window.addEventListener(
  "startMTAEvent",
  function (event) {
    StaticScriptStartMTA(event.detail.jwt, event.detail.policyNumber);
  },
  false
);
