console.log("HDAutomation StaticScriptRunPageScript injected!");

window.StaticScriptRunPageScript = function (script) {
  let result;
  try {
    result = eval(script);
    window.postMessage({
      source: 'HDAutomation-page-script',
      action: 'SCRIPT_EXECUTED',
      success: true,
      result: result
    }, "*");
  } catch (error) {
    console.error("Error executing the script:", error);
    window.postMessage({
      source: 'HDAutomation-page-script',
      action: 'SCRIPT_EXECUTED',
      success: false,
      error: error.toString()
    }, "*");
  }
};

window.addEventListener(
  "runPageScript",
  function (event) {
    StaticScriptRunPageScript(event.detail.script);
  },
  false
);
