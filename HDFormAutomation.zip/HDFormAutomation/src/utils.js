export const decodeJwtToken = (token) => {
    const base64Url = token.split('.')[1]
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/')

    const payload = JSON.parse(atob(base64))

    return payload
}

export const getPolicyNumberFromJWTLatestAUD = (arr) => {
    const policyArray = arr.filter((el) => el.startsWith('guidewire.edge.policy.'))

    const numbersArray = policyArray.map((el) => {
        return parseInt(el.split('.')[3], 10)
    })

    return Math.max(...numbersArray)
}

const numberWords = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine']

const wordsToNumber = (words) => {
    let number = ''
    words.forEach((word) => {
        number += numberWords.indexOf(word).toString()
    })
    return parseInt(number)
}

const numberToWords = (num) => {
    return num
        .toString()
        .split('')
        .map((n) => numberWords[parseInt(n)])
        .join('')
}

const splitIntoNumberWordChunks = (str) => {
    let chunks = []
    let currentChunk = ''

    for (const element of str) {
        if (numberWords.some((word) => word.startsWith(currentChunk + element))) {
            currentChunk += element
        } else {
            chunks.push(currentChunk)
            currentChunk = element
        }
    }

    if (currentChunk) {
        chunks.push(currentChunk)
    }

    return chunks
}

export const incrementString = (str) => {
    let username = str
    let domain = ''

    if (str.includes('@')) {
        const emailParts = str.split('@')
        username = emailParts[0]
        domain = '@' + emailParts[1]
    }

    let chunks = splitIntoNumberWordChunks(username)
    let hasNumberWord = chunks.some((chunk) => numberWords.includes(chunk))

    if (!hasNumberWord) {
        return username + 'one' + domain
    }

    for (let i = chunks.length - 1; i >= 0; i--) {
        if (numberWords.includes(chunks[i])) {
            let numberWordsEndIndex = i
            let numberWordsStartIndex = i

            while (numberWordsStartIndex > 0 && numberWords.includes(chunks[numberWordsStartIndex - 1])) {
                numberWordsStartIndex--
            }

            let number = wordsToNumber(chunks.slice(numberWordsStartIndex, numberWordsEndIndex + 1))
            number++

            if (number > 999) {
                throw new Error('Number is too large')
            }

            let numberWordSequence = numberToWords(number)
            let newChunks = splitIntoNumberWordChunks(numberWordSequence)
            chunks.splice(numberWordsStartIndex, numberWordsEndIndex - numberWordsStartIndex + 1, ...newChunks)

            break
        }
    }

    return chunks.join('') + domain
}
