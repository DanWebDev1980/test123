import { UserType } from '../constants/types'
import { RootState } from './store'

export const selectAutomationName = (state: RootState, automationId: number) => {
    const automation = state.automations.automations.find((a) => a.id === automationId)
    return automation ? automation.name : ''
}

export const selectEnvironmentName = (state: RootState, environmentId: number) => {
    const environment = state.environments.environments.find((a) => a.id === environmentId)
    return environment ? environment.name : ''
}

export const selectActiveEnvironment = (state: RootState) => {
    const environment = state.environments.environments.find((a) => a.id === state.environments.activeEnvironmentId)
    return environment ? environment : null
}

export const selectStepById = (
    state: RootState,
    activeStepId: number,
    currentAutomationId: number,
    stepType: string
) => {
    if (!activeStepId) {
        return null
    }
    const automation = state.automations.automations.find((automation) => automation.id === currentAutomationId)

    const existingStep = automation?.steps.find((step) => step.id === activeStepId && step.step_type === stepType)
    return existingStep ? existingStep : null
}

export const selectUserById = (state: RootState, activeUserId: number): UserType | null => {
    if (!activeUserId) {
        return null
    }
    const existingUser = state.users.users.find((user) => user.id === activeUserId)
    return existingUser ?? null
}

export const selectAutomationById = (state: RootState) => {
    return state.automations.automations.find((automation) => automation.id === state.automations.activeAutomationId)
}

export const selectAutomationStepById = (state: RootState, automationId: number, stepId: number) => {
    // Find the automation using the activeAutomationId
    const automation = state.automations.automations.find((automation) => automation.id === automationId)

    const step = automation?.steps.find((step) => step.id === stepId)
    // Return the step of the found automation, or undefined if not found
    return step ? step : undefined
}
