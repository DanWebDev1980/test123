import { combineReducers } from '@reduxjs/toolkit'
import ExtensionReducer from '../extension/extensionSlice'
import AutomationsReducer from '../extension/features/automations/automationsSlice'
import EnvironmentsReducer from '../extension/features/environments/environmentsSlice'
import StepsReducer from '../extension/features/steps/stepsSlice'
import UsersReducer from '../extension/features/users/usersSlice'
import VariablesReducer from '../extension/features/variables/variablesSlice'
import ExternalAPIReducer from '../extension/services/external-api/externalAPISlice'

const rootReducer = combineReducers({
    extension: ExtensionReducer,
    environments: EnvironmentsReducer,
    variables: VariablesReducer,
    externalAPIS: ExternalAPIReducer,
    automations: AutomationsReducer,
    steps: StepsReducer,
    users: UsersReducer
})

export default rootReducer
