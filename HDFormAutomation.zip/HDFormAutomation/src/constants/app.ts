// constants.js
export const IndexedDBHDAutomations = 'HDFormAutomation'

export const PAGES = {
    USER_ACCOUNTS: 'user-accounts',
    AUTOMATIONS: 'automations',
    STEP_FORM_EDIT: 'step-form-edit',
    STEP_REQUEST_EDIT: 'step-request-edit',
    STEP_SCRIPT_EDIT: 'step-script-edit',
    USER_EDIT: 'user-edit',
    ENVIRONMENTS: 'environments'
}

export const StepStatuses = {
    STEP_READY: 'STEP_READY',
    STEP_RUNNING: 'STEP_RUNNING',
    STEP_FINISHED: 'STEP_FINISHED'
}
