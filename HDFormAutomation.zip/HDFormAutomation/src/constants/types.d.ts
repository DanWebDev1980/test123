export type EnvironmentType = {
    id: number
    name: string
}
export type AddEnvironmentType = {
    name: string
}

export type VariableType = {
    id: number
    name: string
    value: string
}

export type AddVariableType = {
    name: string
    value: string
}

export type EnvironmentAndVariablesType = {
    id: number
    name: string
    variables: VariableType[]
}

// Define the common properties between StepFormType and AddStepFormType
type StepFormCommonType = {
    step_type: 'form'
    step_name?: string
    step_order: number
    element_attributes: {
        [key: string]: any
    }[]
    element_value?: string
    element_innerText?: string
    element_content?: string
    element_class_names?: string | []
    element_tag_name: string
    element_x_path: string
    element_value_type: string
    custom_find: string
    custom_find_value: string
}

// Define the unique properties of StepFormType
type StepFormUniqueType = {
    [key: string]: any
    id: number
    step_run: boolean
    step_status: string
    step_run_error: string
    element_value_environment: EnvironmentAndVariablesType | null
    element_value_environment_variable: string
}

// Define the unique properties of AddStepFormType
type AddStepFormUniqueType = {
    id?: number
    automation_id: number
}

export type StepFormType = StepFormCommonType & StepFormUniqueType
export type AddStepFormType = StepFormCommonType & AddStepFormUniqueType

// Define the common properties between StepRequestType and AddStepRequestType
type StepRequestCommonType = {
    step_type: 'request'
    step_name: string
    step_order: number
    step_request_url: string
    step_request_method: string
    step_request_headers: {
        [key: string]: any
    }[]
    step_request_body: string
    step_request_pre_script: string
    step_request_post_script: string
}

// Define the unique properties of StepRequestType
type StepRequestUniqueType = {
    [key: string]: any
    id: number
    step_run: boolean
    step_status: string
    step_run_error: string
}

// Define the unique properties of AddStepRequestType (if any)
type AddStepRequestUniqueType = {
    id?: number
}

export type StepRequestType = StepRequestCommonType & StepRequestUniqueType
export type AddStepRequestType = StepRequestCommonType & AddStepRequestUniqueType

// Define the common properties between StepScriptType and AddStepScriptType
type StepScriptCommonType = {
    step_type: 'script'
    step_name: string
    step_order: number
    step_script: string
}

// Define the unique properties of StepScriptType
type StepScriptUniqueType = {
    [key: string]: any
    id: number
    step_run: boolean
    step_status: string
    step_run_error: string
}

// Define the unique properties of AddStepScriptType (if any)
type AddStepScriptUniqueType = {
    id?: number
}

export type StepScriptType = StepScriptCommonType & StepScriptUniqueType
export type AddStepScriptType = StepScriptCommonType & AddStepScriptUniqueType

export type StepType = StepFormType | StepRequestType | StepScriptType

export type AutomationAndStepsType = {
    id: number
    name: string
    user_id?: number
    steps: StepType[]
}
export type AutomationAndStepsRecordingType = [AddStepFormType]

// Define the common properties between AutomationType and AddAutomationType
type AutomationCommonType = {
    name: string
}

// Define the unique properties of AutomationType
type AutomationUniqueType = {
    id: number
}

export type AutomationType = AutomationCommonType & AutomationUniqueType
export type AddAutomationType = AutomationCommonType

export type UserAutomationType = {
    user_id: number;
    automation_id: number;
    step_id: number;
    step_type: string;
    step_run: boolean;
};

export type GroupedUserAutomationSteps = {
    automation_id: number
    id: number
    step_run: boolean
    step_id: number
    user_id: number
    step_type: string
}

// Define the common properties between UserType and AddUserType
type UserCommonType = {
    ph_password: string
    ph_dob: string
    ph_first_name: string
    ph_last_name: string
    ph_inception_date: string
    ph_email: string
    ph_post_code: string
    session_UUID: string
    quote_ref: string | null
    created_at: string | null
    created_error: string | null
}

// Define the unique properties of UserType
type UserUniqueType = {
    id: number
}

export type UserType = UserCommonType & UserUniqueType
export type AddUserType = UserCommonType


export type RecordedStepsFromStorageType = AddStepFormType[]
