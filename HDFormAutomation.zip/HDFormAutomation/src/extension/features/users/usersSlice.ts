import { createSlice } from '@reduxjs/toolkit';
import { UserType } from '../../../constants/types';
import { addUser, deleteUser, fetchUsers } from '../../services/indexedDB/users/usersAPI';


type UsersState = {
    activeUserId: UserType['id']
    users: UserType[]
}

const initialState: UsersState = {
    activeUserId: 1,
    users: []
}

export const usersSlice = createSlice({
    name: 'users',
    initialState,
    reducers: {
        setActiveUserId: (state, action) => {
            state.activeUserId = action.payload
        },
        updateUserCreatedAt: (state, action) => {
            const { id, createdAt } = action.payload
            const user = state.users.find((user) => user.id === id)
            if (user) {
                user.created_at = createdAt
            }
        },
        updateUserCreatedError: (state, action) => {
            const { id, createdError } = action.payload
            const user = state.users.find((user) => user.id === id)
            if (user) {
                user.created_error = createdError
            }
        },
        setQuoteRef: (state, action) => {
            const { userId, quoteRef } = action.payload
            const user = state.users.find((user) => user.id === userId)
            if (user) {
                user.quote_ref = quoteRef
            }
        }
    },
    extraReducers: (builder) => {
        builder.addCase(fetchUsers.fulfilled, (state, action) => {
            console.log('Fetched users:', action.payload)
            return {
                ...state,
                users: action.payload
            }
        })
        builder.addCase(fetchUsers.rejected, (_state, action) => {
            // Log the error to the console
            console.error('Failed to fetch users:', action.error)
        })

        builder.addCase(addUser.fulfilled, (state, action) => {
            // Add the new user to the state
            state.users.push(action.payload)
        })

        builder.addCase(deleteUser.fulfilled, (state, action) => {
            // Log the error to the console
            console.log('Deleted user with id:', action.payload)
            state.users = state.users.filter((user) => user.id !== action.payload)
        })
    }
})

export const { setActiveUserId, updateUserCreatedAt, updateUserCreatedError, setQuoteRef } = usersSlice.actions

export default usersSlice.reducer