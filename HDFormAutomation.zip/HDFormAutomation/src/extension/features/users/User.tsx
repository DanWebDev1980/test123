import React, { useEffect, useState } from 'react';
import { unwrapResult } from '@reduxjs/toolkit';
import { PAGES } from '../../../constants/app';
import { AutomationAndStepsType, UserType } from '../../../constants/types';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { RootState } from '../../../store/store';
import { decodeJwtToken, getPolicyNumberFromJWTLatestAUD, incrementString } from '../../../utils';
import DeleteIcon from '../../components/buttons/DeleteIcon';
import DownArrowIcon from '../../components/buttons/DownArrowIcon';
import DuplicateIcon from '../../components/buttons/DuplicateIcon';
import { setCurrentPage } from '../../extensionSlice';
import gwCheckEmail from '../../services/external-api/guide-wire/checkEmail';
import gwGetPasswordToken from '../../services/external-api/guide-wire/getPasswordToken';
import gwLogin from '../../services/external-api/guide-wire/login';
import gwSetNewPassword from '../../services/external-api/guide-wire/setNewPassword';
import useCreatePolicyHolder from '../../services/external-api/users/useCreatePolicyHolder';
import { addUserAutomation, deleteUserAutomation, fetchUserAutomations } from '../../services/indexedDB/automations/automationsAPI';
import { addUser, deleteUser, fetchUsers } from '../../services/indexedDB/users/usersAPI';
import Automations from '../automations/Automations';
import { setActiveUserId } from './usersSlice';


interface UserProps {
    user: UserType
}

const User = ({ user }: UserProps) => {
    const dispatch = useAppDispatch()
    const currentApplication = useAppSelector((state: RootState) => state.extension.currentApplication)
    const loading = useAppSelector((state: RootState) => state.externalAPIS.createPHAddQuote.loading)
    const activeUserId = useAppSelector((state: RootState) => state.users.activeUserId)
    const createPolicyHolderAPI = useCreatePolicyHolder(user)
    const [showAtomations, setShowAutomations] = useState<boolean>(false)
    const [selectedAutomation, setSelectedAutomation] = useState<number>(0)
    const [selectedAutomationToDelete, setSelectedAutomationToDelete] = useState<number>(0)
    const [userAutomations, setUserAutomations] = useState<AutomationAndStepsType[]>([])
    const automations = useAppSelector((state: RootState) => state.automations.automations)
    const [hasAddedAutomation, setHasAddedAutomation] = useState(false)

    useEffect(() => {
        console.log('User.tsx: user: ', user.id)
        console.log('User.tsx: userAutomations: ', userAutomations)
    }, [userAutomations])

    const fetchUAutomations = async () => {
        const userAutomationsFromDB = await fetchUserAutomations(user.id)
        console.log('User: fetching automations', userAutomationsFromDB)
        setUserAutomations(userAutomationsFromDB)
    }

    const editUser = () => {
        dispatch(setActiveUserId(user.id))
        dispatch(setCurrentPage(PAGES.USER_EDIT))
    }

    useEffect(() => {
        fetchUAutomations()
    }, [user.id, automations, showAtomations])

    type TokenDataType = {
        id: string
        result: {
            emailAddress: string
            dateOfBirth: string
            userId: string
            passwordToken: string
            brand: string
        }
        jsonrpc: string
    }

    const createPH = async () => {
        await createPolicyHolderAPI()
    }

    const verifyAndChangePassword = async () => {
        const token = (await gwGetPasswordToken({ emailAddress: user.ph_email, dob: user.ph_dob })) as TokenDataType
        console.log('passwordToken: ', token)
        if (token.result) {
            const setNewPasswordResult = await gwSetNewPassword({
                emailAddress: token.result.emailAddress,
                dob: user.ph_dob,
                passwordToken: token.result.passwordToken,
                password: user.ph_password
            })
            console.log('New Password Set: ', setNewPasswordResult)
        }
    }

    const deleteAutomation = () => {
        dispatch(
            deleteUserAutomation({
                user_id: user.id,
                automation_id: selectedAutomationToDelete
            })
        )
        setSelectedAutomationToDelete(0)
        fetchUAutomations()
    }

    const addAutomation = async () => {
        const newAutomation = {
            user_id: user.id,
            automation_id: selectedAutomation
        }
        await dispatch(addUserAutomation(newAutomation))
        setSelectedAutomation(0)
        setHasAddedAutomation(true)
        fetchUAutomations()
    }

    const removeUser = () => {
        dispatch(deleteUser(user.id))
    }

    const duplicateUser = async () => {
        const firstName = incrementString(user.ph_first_name)
        const email = incrementString(user.ph_email)
        const actionResult = await dispatch(
            addUser({
                ph_password: user.ph_password,
                ph_dob: user.ph_dob,
                ph_first_name: firstName,
                ph_last_name: user.ph_last_name,
                ph_inception_date: user.ph_inception_date,
                ph_email: email,
                ph_post_code: user.ph_post_code,
                session_UUID: user.session_UUID,
                quote_ref: null,
                created_at: null,
                created_error: null
            })
        )

        const newUser = unwrapResult(actionResult)

        if (newUser) {
            // Create an array of promises from dispatching addUserAutomation
            const promises = userAutomations.map((automation) => {
                return dispatch(
                    addUserAutomation({
                        user_id: newUser.id,
                        automation_id: automation.id
                    })
                )
            })

            // Wait until all addUserAutomation promises have resolved
            await Promise.all(promises)

            // Then fetch user automations
            dispatch(fetchUsers())
            fetchUAutomations()
        }
    }

    type CheckEmailResultType = {
        id: string
        result: {
            message: string
            dateOfBirth: string
            userId: string
            emailLoginStatus: string
            resultFlag: boolean
        }
        jsonrpc: string
    }

    type AssociatedGWAccountType = {
        accountNumber: string
    }

    type LoginResultType = {
        message: string
        code: string
        jwtToken: string
        associatedGWAccounts: AssociatedGWAccountType[]
        authenticatingSystem: string
        resultFlag: boolean
    }

    type LoginResponseType = {
        id: string
        result: LoginResultType
        jsonrpc: string
    }

    const mtaLogin = async () => {
        // Query for the active tab in the current window
        console.log('mtaLogin')
        const emailResult = (await gwCheckEmail({ emailAddress: user.ph_email })) as CheckEmailResultType
        console.log('Check email Result: ', emailResult)
        if (emailResult) {
            const loginResult = (await gwLogin({
                dob: user.ph_dob,
                emailAddress: user.ph_email,
                password: user.ph_password,
                userId: emailResult.result.userId
            })) as LoginResponseType
            console.log('Check email loginResult: ', loginResult)
            if (loginResult.result.resultFlag) {
                const jwt = loginResult.result.jwtToken
                const jwtObject = await decodeJwtToken(jwt)
                const policyNumber = getPolicyNumberFromJWTLatestAUD(jwtObject.aud)
                console.log('jwt', jwt)
                console.log('policyNumber', policyNumber)
                console.log('jwtObject', jwtObject)
                chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                    // Send a message to the content script in the active tab
                    if (tabs[0].id)
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'MTA_START',
                            jwt: loginResult.result.jwtToken,
                            policyNumber
                        })
                })
            }
        }
    }

    const runScript = () => {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            // Send a message to the content script in the active tab
            if (tabs[0].id)
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'RUN_PAGE_SCRIPT',
                    script: 'console.log("The script to run")'
                })
        })
    }

    return (
        <>
            <tr key={user.id + 'user_row'}>
                <td className="user-id">{user.id}</td>
                <td className="user-first-name">{user.ph_first_name}</td>
                <td className="user-last-name">{user.ph_last_name}</td>
                <td className="user-email">{user.ph_email}</td>
                <td className="user-quote-ref">{user.quote_ref}</td>
                <td className="table-step-actions">
                    {loading && activeUserId === user.id ? (
                        <div className="loader">Loading</div>
                    ) : (
                        <>
                            <div className="app-actions">
                                {currentApplication === 'GW' ? (
                                    <>
                                        <button className="button-positive-action-1" onClick={() => createPH()}>
                                            Create PH
                                        </button>
                                        <button
                                            className="button-positive-action-1"
                                            onClick={() => verifyAndChangePassword()}>
                                            Verify Change Password
                                        </button>
                                        <div>{user.created_error ?? user.created_at}</div>
                                    </>
                                ) : null}
                                {currentApplication === 'MTA' ? (
                                    <>
                                        <button className="button-positive-action-1" onClick={() => mtaLogin()}>
                                            Login
                                        </button>
                                        <button className="button-positive-action-1" onClick={() => runScript()}>
                                            Run Script
                                        </button>
                                    </>
                                ) : null}
                            </div>
                            <button className="button-positive-action-1" onClick={() => editUser()}>
                                edit
                            </button>
                            <button className="button-positive-action-2" onClick={() => duplicateUser()}>
                                <DuplicateIcon />
                            </button>
                            <button className="button-negative" onClick={() => removeUser()}>
                                <DeleteIcon />
                            </button>
                            <button className="button-info" onClick={() => setShowAutomations(!showAtomations)}>
                                <DownArrowIcon />
                            </button>
                        </>
                    )}
                </td>
            </tr>
            {showAtomations && (
                <>
                    <Automations automations={userAutomations} fetchUAutomations={fetchUAutomations} />
                    <tr key={user.id + 'automations_row'}>
                        <select
                            key={hasAddedAutomation ? 'reset' : ''}
                            onChange={(e) => {
                                console.log(e.target.value)
                                setSelectedAutomation(Number(e.target.value))
                                setHasAddedAutomation(false)
                            }}>
                            <option value={selectedAutomation}>Add Automation</option>
                            {automations.map((automation) => {
                                if (automation.steps.length > 0) {
                                    return (
                                        <option key={automation.id} value={automation.id}>
                                            {automation.name}
                                        </option>
                                    )
                                }
                            })}
                        </select>

                        {!!selectedAutomation && (
                            <button className="button-positive-action-1" onClick={() => addAutomation()}>
                                Add
                            </button>
                        )}
                        {userAutomations.length > 0 && (
                            <select onChange={(e) => setSelectedAutomationToDelete(Number(e.target.value))}>
                                <option value="">Delete Automation</option>
                                {userAutomations.map((automation) => (
                                    <option key={automation.id} value={automation.id}>
                                        {automation.name}
                                    </option>
                                ))}
                            </select>
                        )}
                        {!!selectedAutomationToDelete && (
                            <button className="button-negative" onClick={() => deleteAutomation()}>
                                Delete
                            </button>
                        )}
                    </tr>
                </>
            )}
        </>
    )
}

export default User