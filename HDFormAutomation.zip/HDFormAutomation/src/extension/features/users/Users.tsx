import React from 'react'
import { UserType } from '../../../constants/types'
import User from './User'

interface UsersProps {
    users: UserType[]
}

const Users = ({ users }: UsersProps) => {
    const stepHeaders = (
        <tr>
            <th className="user-id">ID</th>
            <th className="user-first-name">First Name</th>
            <th className="user-last-name">Last Name</th>
            <th className="user-email">Email</th>
            <th className="user-quote-ref">Quote Ref</th>
            <th className="table-step-actions--th">Action</th>
        </tr>
    )

    const userList = users.map((user) => <User key={user.id} user={user} />)

    return (
        <table>
            <tbody>
                {stepHeaders}
                {userList}
            </tbody>
        </table>
    )
}

export default Users
