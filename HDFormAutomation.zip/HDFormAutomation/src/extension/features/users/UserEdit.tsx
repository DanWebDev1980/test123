import React, { useState } from 'react'
import { PAGES } from '../../../constants/app'
import { UserType } from '../../../constants/types'
import { useAppDispatch } from '../../../store/hooks'
import { setCurrentPage } from '../../extensionSlice'
import { fetchUsers, updateUser } from '../../services/indexedDB/users/usersAPI'

type UserEditProps = {
    user: UserType
}

const UserEdit = ({ user }: UserEditProps) => {
    console.log('User edit', user)
    const dispatch = useAppDispatch()
    const [updatedUser, setUpdatedUser] = useState<UserType>(user)

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target
        setUpdatedUser((prevUser) => ({
            ...prevUser,
            [name]: value
        }))
    }

    const handleSave = () => {
        dispatch(updateUser(updatedUser))
        dispatch(fetchUsers())
        dispatch(setCurrentPage(PAGES.USER_ACCOUNTS))
    }

    return (
        <div className="user-edit-container">
            <label>Date Of Birth:</label>
            <input type="text" name="ph_dob" value={updatedUser.ph_dob} onChange={handleChange} />

            <label>Email:</label>
            <input type="text" name="ph_email" value={updatedUser.ph_email} onChange={handleChange} />
            <label>First Name:</label>
            <input type="text" name="ph_first_name" value={updatedUser.ph_first_name} onChange={handleChange} />

            <label>Last Name:</label>
            <input type="text" name="ph_last_name" value={updatedUser.ph_last_name} onChange={handleChange} />

            <label>Password:</label>
            <input type="text" name="ph_password" value={updatedUser.ph_password} onChange={handleChange} />

            <label>Post Code:</label>
            <input type="text" name="ph_post_code" value={updatedUser.ph_post_code} onChange={handleChange} />

            <button onClick={handleSave}>Save</button>
        </div>
    )
}

export default UserEdit
