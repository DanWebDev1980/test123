import React, { useState } from 'react';
import { unwrapResult } from '@reduxjs/toolkit';
import { AddStepFormType, AutomationType, StepType, UserType } from '../../../constants/types'
import { useAppDispatch } from '../../../store/hooks'
import { fetchAutomationsWithSteps } from '../../services/indexedDB/automations/automationsAPI'
import { addAutomationStep, addStep, fetchSteps } from '../../services/indexedDB/steps/stepsAPI'
import StepForm from './StepForm'
import StepRequest from './StepRequest'
import StepScript from './StepScript'

interface StepsProps {
    steps: StepType[]
    automation: AutomationType
    user: UserType | null
    fetchUAutomations?: () => void
}

const Steps = ({ steps, automation, user, fetchUAutomations }: StepsProps) => {
    const [newStepType, setNewStepType] = useState('')
    const dispatch = useAppDispatch()

    const newStep = async () => {
        console.log('new step')
        switch (newStepType) {
            case 'form':
                const newStepData = {
                    step_name: 'New Step',
                    element_attributes: {},
                    element_class_names: '',
                    element_content: '',
                    element_innerText: '',
                    element_tag_name: '',
                    element_value: '',
                    element_x_path: '',
                    element_value_type: '',
                    custom_find: '',
                    custom_find_value: ''
                } as AddStepFormType

                const newStepResult = await dispatch(addStep(newStepData))
                const newStep = unwrapResult(newStepResult)
                if (!newStep) {
                    console.log('no new step ID from const newStepResult = await dispatch(addStep(newStepData))')
                    return
                }
                const newAutomationStep = {
                    automation_id: automation.id,
                    step_id: newStep.id,
                    step_order: steps.length + 1
                }
                dispatch(addAutomationStep(newAutomationStep))
                dispatch(fetchAutomationsWithSteps())
                dispatch(fetchSteps())
                break
            case 'request':
                console.log('new request step')
                break
            case 'script':
                console.log('new script step')
                break
            default:
                break
        }
    }

    const orderedSteps = [...steps].sort((a, b) => a.step_order - b.step_order)

    const orderedStepList = () => {
        return orderedSteps.map((step) => {
            if (step.step_type === 'form') {
                // Replace with a distinguishing property for StepFormType
                return (
                    <StepForm
                        key={step.id}
                        step={step}
                        automation={automation}
                        user={user}
                        fetchUAutomations={fetchUAutomations}
                    />
                )
            } else if (step.step_type === 'request') {
                // Replace with a distinguishing property for StepRequestType
                return <StepRequest key={step.id} step={step} automation={automation} user={user} />
            } else if (step.step_type === 'script') {
                // Replace with a distinguishing property for any other type
                return <StepScript key={step.id} step={step} automation={automation} user={user} />
            } else {
                return null
            }
        })
    }
    console.log('Steps -- orderedSteps', orderedSteps)
    return (
        <table>
            <tbody>
                <tr>
                    <th className="table-step-order">Order</th>
                    <th className="table-step-type">Type</th>
                    <th className="table-step-name">Name</th>
                    <th className="table-step-actions--th">Actions</th>
                </tr>
                {orderedStepList()}
            </tbody>
            <select name="NewStepType" onChange={(e) => setNewStepType(e.target.value)} value={newStepType}>
                <option value="none">None</option>
                <option value="form">Form</option>
                <option value="request">Request</option>
                <option value="script">Script</option>
            </select>
            {newStepType !== '' && (
                <button className="button-info margin-right-5px" onClick={() => newStep()}>
                    New Step
                </button>
            )}
        </table>
    )
}

export default Steps