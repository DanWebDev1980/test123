import React, { useEffect, useState } from 'react'
import { PAGES } from '../../../constants/app'
import { EnvironmentAndVariablesType, StepFormType } from '../../../constants/types'
import { useAppDispatch, useAppSelector } from '../../../store/hooks'
import { setCurrentPage } from '../../extensionSlice'
import { fetchAutomationsWithSteps } from '../../services/indexedDB/automations/automationsAPI'
import { readAllByIndex } from '../../services/indexedDB/indexedDB'
import { fetchSteps, updateStep } from '../../services/indexedDB/steps/stepsAPI'
import { fetchVariable } from '../../services/indexedDB/variables/variablesAPI'

type StepEditProps = {
    step: StepFormType
}

const StepFormEdit = ({ step }: StepEditProps) => {
    console.log('Step edit', step)
    const dispatch = useAppDispatch()
    const environments = useAppSelector((state) => state.environments.environments)
    const [selectedEnvironment, setSelectedEnvironment] = useState<EnvironmentAndVariablesType | null>(null)
    const [environmentVariableValue, setEnvironmentVariableValue] = useState<string>('')
    const [updatedStep, setUpdatedStep] = useState<StepFormType>(step)
    const [newAttributeKey, setNewAttributeKey] = useState('')
    const [newAttributeValue, setNewAttributeValue] = useState('')

    const handleNewAttributeKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewAttributeKey(e.target.value)
    }

    const handleNewAttributeValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewAttributeValue(e.target.value)
    }

    const handleAddAttribute = () => {
        setUpdatedStep((prevStep) => {
            const updatedAttributes = [...prevStep.element_attributes, { [newAttributeKey]: newAttributeValue }]
            return {
                ...prevStep,
                element_attributes: updatedAttributes
            }
        })
        setNewAttributeKey('')
        setNewAttributeValue('')
    }

    const handleDeleteAttribute = (idx: number) => {
        setUpdatedStep((prevStep) => {
            const updatedAttributes = prevStep.element_attributes.filter((_, index) => index !== idx);
            return {
                ...prevStep,
                element_attributes: updatedAttributes
            };
        });
    }

    useEffect(() => {
        readAllByIndex('environment', 'name')
        if (updatedStep.element_value_environment) {
            setSelectedEnvironment(updatedStep.element_value_environment)
        }
    }, [])

    useEffect(() => {
        getEnvironmentVariableValue()
    }, [selectedEnvironment, updatedStep.element_value_environment_variable])

    const getEnvironmentVariableValue = async () => {
        if (selectedEnvironment && updatedStep.element_value_environment_variable) {
            // Dispatch the action and wait for it to finish
            const actionResult = await dispatch(fetchVariable(parseInt(updatedStep.element_value_environment_variable)))

            // Check if the action was fulfilled
            if (fetchVariable.fulfilled.match(actionResult)) {
                const variable = actionResult.payload

                if (variable) {
                    setEnvironmentVariableValue(variable.value)
                }
            }
        }
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target
        setUpdatedStep((prevStep) => ({
            ...prevStep,
            [name]: value
        }))
    }

    const handleElementAttributesChange = (
        index: number,
        key: string,
        value: string
    ) => {
        setUpdatedStep((prevStep) => {
            const updatedAttributesCopy = [...prevStep.element_attributes];
            updatedAttributesCopy[index][key] = value
            return {
                ...prevStep,
                element_attributes: updatedAttributesCopy
            };
        });
    }

    const handleEnvironmentChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
        const { value } = e.target
        if (value === 'none') {
            setSelectedEnvironment(null)
            setUpdatedStep((prevStep) => ({
                ...prevStep,
                element_value_environment: null,
                element_value_environment_variable: ''
            }))
            setEnvironmentVariableValue('')
            return
        }
        const environment = environments.find((env) => env.id.toString() === value)
        if (environment) {
            setSelectedEnvironment(environment)
            setUpdatedStep((prevStep) => ({
                ...prevStep,
                element_value_environment: environment
            }))
        }
    }

    const handleSave = () => {
        dispatch(updateStep(updatedStep))
        dispatch(fetchSteps())
        dispatch(fetchAutomationsWithSteps())
        dispatch(setCurrentPage(PAGES.AUTOMATIONS))
    }

    return (
        <div className="step-edit-container">
            <label>ID:</label>
            <input type="number" name="id" value={updatedStep.id} onChange={handleChange} />

            <label>Step Detail:</label>
            <textarea name="step_name" value={updatedStep.step_name} onChange={handleChange}></textarea>

            <label>Element Attributes:</label>
            {updatedStep.element_attributes.length > 0 &&
                updatedStep.element_attributes.map((attributeObj, idx) =>
                    Object.keys(attributeObj).map((key) => (
                        <div key={`${idx}-${key}`}>
                            <label>{key}:</label>
                            <input
                                type="text"
                                name={key}
                                value={attributeObj[key]}
                                onChange={(e) => handleElementAttributesChange(idx, key, e.target.value)}
                            />
                            <button onClick={() => handleDeleteAttribute(idx)}>Delete Attribute</button>
                        </div>
                    ))
                )}

            <div>
                <label>New attribute key:</label>
                <input type="text" value={newAttributeKey} onChange={handleNewAttributeKeyChange} />
                <label>New attribute value:</label>
                <input type="text" value={newAttributeValue} onChange={handleNewAttributeValueChange} />
                <button onClick={handleAddAttribute}>Add attribute</button>
            </div>

            <label>Element Value:</label>
            <input
                type="text"
                name="element_value"
                value={environmentVariableValue ? environmentVariableValue : updatedStep.element_value}
                onChange={handleChange}
            />
            <label>Value Type:</label>
            <select name="element_value_type" onChange={handleChange} value={updatedStep.element_value_type}>
                <option value="none">None</option>
                <option value="environment">Environment</option>
            </select>
            {updatedStep.element_value_type === 'environment' ? (
                <>
                    <label>environment:</label>
                    <select
                        name="element_value_environment"
                        onChange={handleEnvironmentChange}
                        value={updatedStep.element_value_environment?.id ?? 'none'}>
                        <option value="none">None</option>
                        {environments.map((environment) => (
                            <option key={environment.id} value={environment.id}>
                                {environment.name}
                            </option>
                        ))}
                    </select>
                    <label>Environment Variable:</label>
                    <select
                        name="element_value_environment_variable"
                        onChange={handleChange}
                        value={updatedStep.element_value_environment_variable || 'none'}>
                        <option value="none">None</option>
                        {selectedEnvironment?.variables.map((variable) => (
                            <option key={variable.id} value={variable.id}>
                                {variable.name}
                            </option>
                        ))}
                    </select>
                </>
            ) : null}

            <label>Element InnerText:</label>
            <input type="text" name="element_innerText" value={updatedStep.element_innerText} onChange={handleChange} />

            <label>Element Content:</label>
            <input type="text" name="element_content" value={updatedStep.element_content} onChange={handleChange} />

            <label>Element Class Names:</label>
            <input
                type="text"
                name="element_class_names"
                value={updatedStep.element_class_names}
                onChange={handleChange}
            />

            <label>Element Tag Name:</label>
            <input type="text" name="element_tag_name" value={updatedStep.element_tag_name} onChange={handleChange} />

            <label>Element X Path:</label>
            <input type="text" name="element_x_path" value={updatedStep.element_x_path} onChange={handleChange} />
            <label>Custom find element:</label>
            <input type="text" name="custom_find" value={updatedStep.custom_find} onChange={handleChange} />
            <label>Custom find value:</label>
            <input type="text" name="custom_find_value" value={updatedStep.custom_find_value} onChange={handleChange} />

            <button onClick={handleSave}>Save</button>
        </div>
    )
}

export default StepFormEdit
