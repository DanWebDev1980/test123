import React, { useState } from 'react'
import { PAGES } from '../../../constants/app'
import { StepRequestType } from '../../../constants/types'
import { useAppDispatch } from '../../../store/hooks'
import { setCurrentPage } from '../../extensionSlice'
import { fetchAutomationsWithSteps } from '../../services/indexedDB/automations/automationsAPI'
import { fetchSteps, updateStep } from '../../services/indexedDB/steps/stepsAPI'

type StepRequestEditProps = {
    step: StepRequestType
}

const StepRequestEdit = ({ step }: StepRequestEditProps) => {
    console.log('Step request edit', step)
    const dispatch = useAppDispatch()
    const [updatedStep, setUpdatedStep] = useState(step)
    const [newHeaderKey, setNewHeaderKey] = useState('')
    const [newHeaderValue, setNewHeaderValue] = useState('')

    const handleNewHeaderKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewHeaderKey(e.target.value)
    }

    const handleNewHeaderValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewHeaderValue(e.target.value)
    }

    const handleAddHeader = () => {
        const newHeader = { [newHeaderKey]: newHeaderValue }
        setUpdatedStep((prevStep) => ({
            ...prevStep,
            step_request_headers: [...prevStep.step_request_headers, newHeader]
        }))
        setNewHeaderKey('')
        setNewHeaderValue('')
    }

    const handleDeleteHeader = (index: number) => {
        setUpdatedStep((prevStep) => {
            const headersCopy = [...prevStep.step_request_headers]
            headersCopy.splice(index, 1)
            return {
                ...prevStep,
                step_request_headers: headersCopy
            }
        })
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target
        setUpdatedStep((prevStep) => ({
            ...prevStep,
            [name]: value
        }))
    }

    const handleElementHeadersChange = (index: number, key: string, value: any) => {
        setUpdatedStep((prevStep) => {
            const headersCopy = [...prevStep.step_request_headers]
            headersCopy[index][key] = value
            return {
                ...prevStep,
                step_request_headers: headersCopy
            }
        })
    }
    const handleSave = () => {
        console.log('StepRequestEdit -- handleSave -- updatedStep:', updatedStep)
        dispatch(updateStep(updatedStep))
        dispatch(fetchSteps())
        dispatch(fetchAutomationsWithSteps())
        dispatch(setCurrentPage(PAGES.AUTOMATIONS))
    }
    return (
        <div className="step-edit-container">
            <label>Name:</label>
            <input type="text" name="step_name" value={updatedStep.step_name} onChange={handleChange} />
            <label>URL:</label>
            <input type="text" name="step_request_url" value={updatedStep.step_request_url} onChange={handleChange} />
            <label>METHOD:</label>
            <input
                type="text"
                name="step_request_method"
                value={updatedStep.step_request_method}
                onChange={handleChange}
            />

            <label>Headers:</label>
            {updatedStep.step_request_headers.length > 0 &&
                updatedStep.step_request_headers.map((headerObj, idx) =>
                    Object.keys(headerObj).map((key) => (
                        <div key={`${idx}-${key}`}>
                            <label>{key}:</label>
                            <input
                                type="text"
                                name={key}
                                value={headerObj[key]}
                                onChange={(e) => handleElementHeadersChange(idx, key, e.target.value)}
                            />
                            <button onClick={() => handleDeleteHeader(idx)}>Delete Header</button>
                        </div>
                    ))
                )}
            <div>
                <label>New header key:</label>
                <input type="text" value={newHeaderKey} onChange={handleNewHeaderKeyChange} />
                <label>New header value:</label>
                <input type="text" value={newHeaderValue} onChange={handleNewHeaderValueChange} />
                <button onClick={handleAddHeader}>Add attribute</button>
            </div>
            <label>Body:</label>
            <textarea name="step_request_body" value={updatedStep.step_request_body} onChange={handleChange}></textarea>
            <label>Pre-request Script:</label>
            <textarea
                name="step_request_pre_script"
                value={updatedStep.step_request_pre_script}
                onChange={handleChange}></textarea>
            <label>Post-request Script:</label>
            <textarea
                name="step_request_post_script"
                value={updatedStep.step_request_post_script}
                onChange={handleChange}></textarea>
            <button onClick={handleSave}>Save</button>
        </div>
    )
}

export default StepRequestEdit
