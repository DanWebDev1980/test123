import React from 'react'
import { PAGES } from '../../../constants/app'
import DeleteIcon from '../../components/buttons/DeleteIcon'
import DownArrowIcon from '../../components/buttons/DownArrowIcon'
import PlayIcon from '../../components/buttons/PlayIcon'

type StepActionsProps = {
    editStep: () => void
    moveUp: () => {}
    moveDown: () => {}
    runStep: () => void
    removeStep: () => void
    toggleInfo: () => void
    page: string
    run: boolean
    toggleRun: () => void
}

export const StepActions = ({
    editStep,
    moveUp,
    moveDown,
    runStep,
    removeStep,
    toggleInfo,
    page,
    run,
    toggleRun
}: StepActionsProps) => {
    return (
        <>
            <td className="table-step-actions">
                {page === PAGES.USER_ACCOUNTS ? (
                    <>
                        <button className="button-positive-action-1" onClick={() => runStep()}>
                            <PlayIcon />
                        </button>
                        <button className="button-info" onClick={() => toggleInfo()}>
                            <DownArrowIcon />
                        </button>
                        <div className="button-group-step-run">
                            <label>Run</label>
                            <input type="checkbox" name="open-automations" checked={run} onChange={() => toggleRun()} />
                        </div>
                    </>
                ) : (
                    <>
                        <button className="button-positive-action-1" onClick={() => editStep()}>
                            edit
                        </button>
                        <button className="button-positive-action-1" onClick={() => moveUp()}>
                            Up
                        </button>
                        <button className="button-positive-action-1" onClick={() => moveDown()}>
                            Down
                        </button>
                        <button className="button-positive-action-1" onClick={() => runStep()}>
                            <PlayIcon />
                        </button>
                        <button className="button-negative" onClick={() => removeStep()}>
                            <DeleteIcon />
                        </button>
                        <button className="button-info" onClick={() => toggleInfo()}>
                            <DownArrowIcon />
                        </button>
                        <div className="button-group-step-run">
                            <label>Run</label>
                            <input type="checkbox" name="open-automations" checked={run} onChange={() => toggleRun()} />
                        </div>
                    </>
                )}
            </td>
        </>
    )
}
