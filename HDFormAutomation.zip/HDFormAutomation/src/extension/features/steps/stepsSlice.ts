import { createSlice } from '@reduxjs/toolkit';
import { StepFormType, StepType } from '../../../constants/types'
import { deleteStep, fetchSteps, updateStep } from '../../services/indexedDB/steps/stepsAPI'

type StepsState = {
    activeStepId: StepFormType['id'] | null
    steps: StepType[]
}

const initialState: StepsState = {
    activeStepId: null,
    steps: []
}

export const stepsSlice = createSlice({
    name: 'steps',
    initialState,
    reducers: {
        setActiveStepId: (state, action) => {
            state.activeStepId = action.payload
        }
    },
    extraReducers: (builder) => {
        builder.addCase(fetchSteps.fulfilled, (state, action) => {
            console.log('Fetched steps:', action.payload)
            return {
                ...state,
                steps: action.payload
            }
        })
        builder.addCase(fetchSteps.rejected, (_state, action) => {
            // Log the error to the console
            console.error('Failed to fetch steps:', action.error)
        })
        builder.addCase(updateStep.fulfilled, (state, action) => {
            const updatedStep = action.payload
            if (updatedStep) {
                const updatedSteps = state.steps.map((step) => (step.id === updatedStep.id ? updatedStep : step))
                return {
                    ...state,
                    steps: updatedSteps
                }
            }
            return state
        })
        builder.addCase(deleteStep.fulfilled, (state, action) => {
            const stepId = action.payload
            if (stepId) {
                // Remove the step with the returned stepId from the state
                const updatedSteps = state.steps.filter((step) => step.id !== stepId)
                state.steps = updatedSteps
            }
            return state
        })
    }
})

export const { setActiveStepId } = stepsSlice.actions

export default stepsSlice.reducer