import React, { useEffect, useState } from 'react'
import { PAGES } from '../../../constants/app'
import { StepScriptType } from '../../../constants/types'
import { useAppDispatch } from '../../../store/hooks'
import { setCurrentPage } from '../../extensionSlice'
import { fetchAutomationsWithSteps } from '../../services/indexedDB/automations/automationsAPI'
import { fetchSteps, updateStep } from '../../services/indexedDB/steps/stepsAPI'

type StepScriptEditProps = {
    step: StepScriptType
}

const StepScriptEdit = ({ step }: StepScriptEditProps) => {
    const dispatch = useAppDispatch()
    const [updatedStep, setUpdatedStep] = useState<StepScriptType>(step)
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target
        setUpdatedStep((prevStep) => ({
            ...prevStep,
            [name]: value
        }))
    }

    useEffect(() => {
        console.log(updateStep)
    }, [updatedStep])
    const handleSave = () => {
        dispatch(updateStep(updatedStep))
        dispatch(fetchSteps())
        dispatch(fetchAutomationsWithSteps())
        dispatch(setCurrentPage(PAGES.AUTOMATIONS))
    }
    return (
        <div className="step-edit-container">
            <label>Script:</label>
            <textarea name="step_script" value={updatedStep.step_script} onChange={handleChange}></textarea>
            <button onClick={handleSave}>Save</button>
        </div>
    )
}

export default StepScriptEdit
