/* global chrome */
import React, { useState } from 'react';
import { PAGES } from '../../../constants/app';
import { AutomationType, StepScriptType, UserType } from '../../../constants/types';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { RootState } from '../../../store/store';
import { setCurrentPage } from '../../extensionSlice';
import useRunSteps from '../../services/automations/useRunSteps';
import { fetchAutomationsWithSteps, toggleUserAutomationRunStep } from '../../services/indexedDB/automations/automationsAPI';
import { deleteStep, fetchSteps, moveStepDown, moveStepUp } from '../../services/indexedDB/steps/stepsAPI';
import { setactiveAutomationId } from '../automations/automationsSlice';
import { StepActions } from './StepActions';
import { setActiveStepId } from './stepsSlice';



interface StepScriptProps {
    step: StepScriptType
    user: UserType | null
    automation: AutomationType
    fetchUAutomations?: () => void
}

const StepScript = ({ step, user, automation, fetchUAutomations }: StepScriptProps) => {
    console.log('StepScript - Step:', step)
    const dispatch = useAppDispatch()
    const runStep = useRunSteps()
    const page = useAppSelector((state: RootState) => state.extension.currentPage)
    const [infoOpen, setInfoOpen] = useState(false)

    const editStep = () => {
        dispatch(fetchSteps())
        dispatch(setActiveStepId(step.id))
        dispatch(setactiveAutomationId(automation.id))
        dispatch(setCurrentPage(PAGES.STEP_SCRIPT_EDIT))
    }

    const removeStep = () => {
        dispatch(deleteStep(step))
        dispatch(fetchAutomationsWithSteps())
        dispatch(fetchSteps())
    }

    const moveUp = async () => {
        await dispatch(moveStepUp(step.id))
        dispatch(fetchAutomationsWithSteps())
        dispatch(fetchSteps())
    }
    const moveDown = async () => {
        await dispatch(moveStepDown(step.id))
        dispatch(fetchAutomationsWithSteps())
        dispatch(fetchSteps())
    }

    const toggleRun = async () => {
        if (user?.id && automation.id && fetchUAutomations) {
            await dispatch(
                toggleUserAutomationRunStep({ automationId: automation.id, userId: user.id, stepId: step.id })
            )
            fetchUAutomations()
        }
    }

    const toggleInfo = () => {
        setInfoOpen(!infoOpen)
    }

    const handleRunStep = () => {
        if (!user) return
        runStep([step], automation, user)
    }
    return (
        <>
            <tr key={`${step.id}_${step.step_name}`}>
                <td className="table-step-order" key={step.id}>
                    {step.step_order}
                </td>
                <td className="table-step-type" key={step.id}>
                    {step.step_type}
                </td>
                <td className="table-step-name" key={step.id}>
                    {step.step_name}
                </td>
                <StepActions
                    editStep={editStep}
                    moveUp={moveUp}
                    moveDown={moveDown}
                    runStep={() => handleRunStep()}
                    removeStep={removeStep}
                    toggleInfo={toggleInfo}
                    page={page}
                    run={step.step_run}
                    toggleRun={toggleRun}
                />
            </tr>
            {infoOpen ? (
                <tr>
                    <td>Script info</td>
                </tr>
            ) : null}
        </>
    )
}

export default StepScript