/* global chrome */
import React, { useState } from 'react';
import { PAGES } from '../../../constants/app';
import { AutomationType, StepFormType, UserType } from '../../../constants/types';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { RootState } from '../../../store/store';
import { setCurrentPage } from '../../extensionSlice';
import useRunSteps from '../../services/automations/useRunSteps';
import { fetchAutomationsWithSteps, toggleUserAutomationRunStep } from '../../services/indexedDB/automations/automationsAPI';
import { deleteStep, fetchSteps, moveStepDown, moveStepUp } from '../../services/indexedDB/steps/stepsAPI';
import { setactiveAutomationId } from '../automations/automationsSlice';
import { StepActions } from './StepActions';
import { setActiveStepId } from './stepsSlice';


interface StepFormProps {
    step: StepFormType
    user: UserType | null
    automation: AutomationType
    fetchUAutomations?: () => void
}

const StepForm = ({ step, user, automation, fetchUAutomations }: StepFormProps) => {
    console.log('StepForm - Step:', step)
    const dispatch = useAppDispatch()
    const runStep = useRunSteps()
    const page = useAppSelector((state: RootState) => state.extension.currentPage)
    const [infoOpen, setInfoOpen] = useState(false)

    const editStep = () => {
        dispatch(fetchSteps())
        dispatch(setActiveStepId(step.id))
        dispatch(setactiveAutomationId(automation.id))
        dispatch(setCurrentPage(PAGES.STEP_FORM_EDIT))
    }

    const removeStep = () => {
        dispatch(deleteStep(step))
        dispatch(fetchAutomationsWithSteps())
        dispatch(fetchSteps())
    }

    const moveUp = async () => {
        await dispatch(moveStepUp(step.id))
        dispatch(fetchAutomationsWithSteps())
        dispatch(fetchSteps())
    }
    const moveDown = async () => {
        await dispatch(moveStepDown(step.id))
        dispatch(fetchAutomationsWithSteps())
        dispatch(fetchSteps())
    }

    const toggleRun = async () => {
        if (user?.id && automation.id && fetchUAutomations) {
            await dispatch(
                toggleUserAutomationRunStep({ automationId: automation.id, userId: user.id, stepId: step.id })
            )
            fetchUAutomations()
        }
    }

    const toggleInfo = () => {
        setInfoOpen(!infoOpen)
    }

    const handleRunStep = () => {
        if (!user) return
        runStep([step], automation, user)
    }

    return (
        <>
            <tr key={step.id} className={`step-status-${step.step_status}`}>
                <td className="table-step-order" key={step.id}>
                    {step.step_order}
                </td>
                <td className="table-step-type" key={step.id}>
                    {step.step_type}
                </td>
                <td className="table-step-name" key={step.id}>
                    {step.step_name}
                </td>
                <StepActions
                    editStep={editStep}
                    moveUp={moveUp}
                    moveDown={moveDown}
                    runStep={() => handleRunStep()}
                    removeStep={removeStep}
                    toggleInfo={toggleInfo}
                    page={page}
                    run={step.step_run}
                    toggleRun={toggleRun}
                />
            </tr>
            {infoOpen ? (
                <tr>
                    <td className="step-tag-name" key={step.id}>
                        {step.element_tag_name}
                    </td>
                    <td className="step-value" key={step.id}>
                        {step.element_value}
                    </td>
                </tr>
            ) : null}
        </>
    )
}

export default StepForm