import { PayloadAction, createSlice } from '@reduxjs/toolkit'
import { AutomationAndStepsType } from '../../../constants/types'
import { fetchAutomationsWithSteps, updateAutomationName } from '../../services/indexedDB/automations/automationsAPI'

type AutomationsState = {
    activeAutomationId: AutomationAndStepsType['id'] | null
    automations: AutomationAndStepsType[]
}

type updateAutomationStepPayload = {
    automationId: number
    stepId: number
    field: string
    value: string
}
type updateAutomationStepAction = PayloadAction<updateAutomationStepPayload>

const initialState: AutomationsState = {
    activeAutomationId: null,
    automations: []
}

export const automationsSlice = createSlice({
    name: 'automations',
    initialState,
    reducers: {
        setactiveAutomationId: (state, action) => {
            state.activeAutomationId = action.payload
        },
        updateAutomationStep: (state, action: updateAutomationStepAction) => {
            const automation = state.automations.find((automation) => automation.id === action.payload.automationId)
            const step = automation?.steps.find((step) => step.id === action.payload.stepId)
            if (step) step[action.payload.field] = action.payload.value
        }
    },
    extraReducers: (builder) => {
        builder.addCase(fetchAutomationsWithSteps.fulfilled, (state, action) => {
            console.log('Fetched automations:', action.payload)
            return {
                ...state,
                automations: action.payload
            }
        })
        builder.addCase(fetchAutomationsWithSteps.rejected, (_state, action) => {
            // Log the error to the console
            console.error('Failed to fetch automations:', action.error)
        })
        builder.addCase(updateAutomationName.fulfilled, (state, action) => {
            const automation = state.automations.find((automation) => automation.id === action.payload.automationId)
            if (automation) {
                automation.name = action.payload.automationName
            }
        })
    }
})

export const { setactiveAutomationId, updateAutomationStep } = automationsSlice.actions

export default automationsSlice.reducer
