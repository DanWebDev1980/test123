/* global chrome */
import React, { useState } from 'react';
import { unwrapResult } from '@reduxjs/toolkit'
import { AutomationAndStepsType } from '../../../constants/types'
import { useAppDispatch, useAppSelector } from '../../../store/hooks'
import { selectAutomationName, selectUserById } from '../../../store/selectors'
import { RootState } from '../../../store/store'
import DeleteIcon from '../../components/buttons/DeleteIcon'
import DownArrowIcon from '../../components/buttons/DownArrowIcon'
import DuplicateIcon from '../../components/buttons/DuplicateIcon'
import PlayIcon from '../../components/buttons/PlayIcon'
import RecordIcon from '../../components/buttons/RecordIcon'
import TextInput from '../../components/inputs/TextInput'
import { setExtensionIsRecording } from '../../extensionSlice'
import useRunSteps from '../../services/automations/useRunSteps'
import {
    addAutomation,
    deleteAutomation,
    fetchAutomationsWithSteps,
    updateAutomationName
} from '../../services/indexedDB/automations/automationsAPI'
import { addAutomationStep } from '../../services/indexedDB/steps/stepsAPI'
import Steps from '../steps/Steps'
import { setactiveAutomationId } from './automationsSlice'

interface AutomationProps {
    automation: AutomationAndStepsType
    fetchUAutomations?: () => void
}

const Automation = ({ automation, fetchUAutomations }: AutomationProps) => {
    console.log('automation', automation)
    const automationName = useAppSelector((state: RootState) => selectAutomationName(state, automation.id))
    const page = useAppSelector((state: RootState) => state.extension.currentPage)
    const [open, setOpen] = useState(false)
    const extensionRecording = useAppSelector((state: RootState) => state.extension.isRecording)
    const currentUserId = useAppSelector((state: RootState) => state.users.activeUserId)
    const currentUser = useAppSelector((state: RootState) =>
        currentUserId ? selectUserById(state, currentUserId) : null
    )
    const runSteps = useRunSteps()
    const dispatch = useAppDispatch()
    const updateAutomation = async (e: React.ChangeEvent<HTMLInputElement>) => {
        await dispatch(updateAutomationName({ automationId: automation.id, automationName: e.target.value }))
    }

    const duplicateAutomation = async () => {
        const actionResult = await dispatch(
            addAutomation({
                name: automation.name
            })
        )
        const newAutomation = unwrapResult(actionResult)
        if (newAutomation) {
            automation.steps.forEach((step) => {
                dispatch(
                    addAutomationStep({
                        automation_id: newAutomation.id,
                        step_id: step.id,
                        step_order: automation.steps.indexOf(step) + 1
                    })
                )
            })
            dispatch(fetchAutomationsWithSteps())
        }
    }

    const removeAutomation = () => {
        dispatch(deleteAutomation(automation.id))
        dispatch(fetchAutomationsWithSteps())
    }

    const record = () => {
        dispatch(setExtensionIsRecording(true))
        dispatch(setactiveAutomationId(automation.id))
        chrome.storage.local.set({}, function () {
            console.log('recordedSteps are cleared')
        })
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.runtime.sendMessage({
                action: 'START_RECORDING',
                tab: tabs[0]
            })
        })
    }

    const handleRunSteps = () => {
        if (!currentUser) return
        runSteps(automation.steps, automation, currentUser)
    }

    return (
        <>
            <tr>
                {extensionRecording ? null : (
                    <>
                        {extensionRecording ? (
                            <button className="button-negative">Stop Recording</button>
                        ) : (
                            <>
                                <TextInput
                                    value={automationName}
                                    handleOnChange={(e) => updateAutomation(e)}
                                    disabled={page === 'user-accounts'}
                                />
                                {page === 'automations' ? (
                                    <button className="button-positive-action-3" onClick={() => record()}>
                                        <RecordIcon />
                                    </button>
                                ) : null}
                                <button className="button-positive-action-1" onClick={() => handleRunSteps()}>
                                    <PlayIcon />
                                </button>
                                {page === 'automations' ? (
                                    <>
                                        <button
                                            className="button-positive-action-2 margin-left-auto"
                                            onClick={() => duplicateAutomation()}>
                                            <DuplicateIcon />
                                        </button>
                                        <button className="button-negative" onClick={() => removeAutomation()}>
                                            <DeleteIcon />
                                        </button>
                                    </>
                                ) : null}
                                <button className="button-info margin-right-5px" onClick={() => setOpen(!open)}>
                                    <DownArrowIcon />
                                </button>
                            </>
                        )}
                    </>
                )}
            </tr>
            {open && (
                <Steps
                    steps={automation.steps}
                    automation={automation}
                    user={currentUser}
                    fetchUAutomations={fetchUAutomations}
                />
            )}
        </>
    )
}

export default Automation