import React, { useEffect } from 'react'
import { AutomationAndStepsType } from '../../../constants/types'
import Automation from './Automation'

interface AutomationsProps {
    automations: AutomationAndStepsType[]
    fetchUAutomations?: () => void
}

const Automations = ({ automations, fetchUAutomations }: AutomationsProps) => {
    useEffect(() => {
        console.log('Automations.tsx: automations: ', automations)
    }, [automations])
    const automationList = () =>
        automations.map((automation) => {
            return <Automation key={automation.id} automation={automation} fetchUAutomations={fetchUAutomations} />
        })

    return (
        <table>
            <tbody>{automationList()}</tbody>
        </table>
    )
}

export default Automations
