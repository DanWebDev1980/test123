import { unwrapResult } from '@reduxjs/toolkit';
import { AddStepFormType, RecordedStepsFromStorageType } from '../../../constants/types';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { selectAutomationById } from '../../../store/selectors';
import { RootState } from '../../../store/store';
import { setExtensionIsRecording } from '../../extensionSlice';
import { fetchAutomationsWithSteps } from '../../services/indexedDB/automations/automationsAPI';
import { addAutomationStep, addStep } from '../../services/indexedDB/steps/stepsAPI';
import { setactiveAutomationId } from '../automations/automationsSlice';


const useRecording = () => {
    const dispatch = useAppDispatch()
    const automation = useAppSelector((state: RootState) => selectAutomationById(state))

    const getRecordedStepsFromStorage = (): Promise<RecordedStepsFromStorageType> => {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get({ recordedSteps: [] }, function (result) {
                if (chrome.runtime.lastError) {
                    console.error('Error getting recordedSteps:', chrome.runtime.lastError)
                    reject(chrome.runtime.lastError)
                } else {
                    console.log('Got recordedSteps from storage:', result.recordedSteps)
                    resolve(result.recordedSteps)
                }
            })
        })
    }

    const stopRecording = async () => {
        const stepsFromStorage = await getRecordedStepsFromStorage()
        console.dir('Exension storage recordedSteps:' + JSON.stringify(stepsFromStorage))

        if (!automation) {
            console.error('Automation is not found')
            return
        }

        const formattedSteps: AddStepFormType[] = []
        stepsFromStorage.forEach((step: any) => {
            if (!step) {
                return
            }
            const stepOrder = automation.steps.length + formattedSteps.length + 1
            const newStep: AddStepFormType = {
                id: stepOrder,
                step_type: 'form',
                step_order: stepOrder,
                step_name: '',
                automation_id: automation.id,
                element_attributes: step.attributes,
                element_value: step.value ? step.value : '',
                element_innerText: step.innerText ? step.innerText : '',
                element_content: step.content ? step.content : '',
                element_class_names: step.classNames ? step.classNames : [],
                element_tag_name: step.tagName ? step.tagName : '',
                element_x_path: step.xpath ? step.xpath : '',
                element_value_type: '',
                custom_find: '',
                custom_find_value: ''
            }
            formattedSteps.push(newStep)
        })

        const uniqueFormattedSteps = [
            ...formattedSteps
                .reduceRight((map, step) => {
                    if (!map.has(JSON.stringify(step.element_attributes))) {
                        map.set(JSON.stringify(step.element_attributes), step)
                    }
                    return map
                }, new Map())
                .values()
        ]

        console.log('Save Formatted steps to indexedDB: ' + JSON.stringify(formattedSteps))
        const stepPromises = uniqueFormattedSteps.map(async (step) => {
            const addStepResult = await dispatch(
                addStep({
                    step_name: step.step_name,
                    element_attributes: step.element_attributes,
                    element_value: step.element_value,
                    element_innerText: step.element_innerText,
                    element_content: step.element_content,
                    element_class_names: step.element_class_names,
                    element_tag_name: step.element_tag_name,
                    element_x_path: step.element_x_path,
                    element_value_type: step.element_value_type,
                    custom_find: step.custom_find,
                    custom_find_value: step.custom_find_value,
                    step_type: 'form',
                    step_order: 0,
                    automation_id: automation.id
                })
            )
            const newStep = unwrapResult(addStepResult)
            if (!newStep) return
            const AddAutomationStepResult = await dispatch(
                addAutomationStep({
                    automation_id: step.automation_id,
                    step_id: newStep.id,
                    step_order: step.step_order
                })
            )
            return unwrapResult(AddAutomationStepResult)
        })

        await Promise.all(stepPromises)
        
        dispatch(setExtensionIsRecording(false))
        dispatch(setactiveAutomationId(0))
        chrome.storage.local.set({ recordedSteps: [] }, function () {
            console.log('recordedSteps are cleared')
        })
        dispatch(fetchAutomationsWithSteps())
    }

    const checkIfRecording = () => {
        chrome.storage.local.get({ recording: 'finished' }, function (result) {
            if (chrome.runtime.lastError) {
                console.error('Error getting recording:', chrome.runtime.lastError)
            } else {
                console.log('Got recording from storage:', result.recording)
                if (result.recording === 'finished') {
                    stopRecording()
                    chrome.storage.local.set({ recording: 'not started' }, function () {
                        console.log('recording is set to not started')
                    })
                }
            }
        })
    }

    return { stopRecording, checkIfRecording }
}

export default useRecording