import { createSlice } from '@reduxjs/toolkit'
import { EnvironmentAndVariablesType } from '../../../constants/types'
import {
    fetchEnvironmentWithVariables,
    updateEnvironmentName
} from '../../services/indexedDB/environments/environmentsAPI'
import { updateVariable } from '../../services/indexedDB/variables/variablesAPI'

type EnvironmentsState = {
    activeEnvironmentId: EnvironmentAndVariablesType['id'] | null
    environments: EnvironmentAndVariablesType[]
}

const initialState: EnvironmentsState = {
    activeEnvironmentId: null,
    environments: []
}

export const environmentsSlice = createSlice({
    name: 'environments',
    initialState,
    reducers: {
        setactiveEnvironmentId: (state, action) => {
            state.activeEnvironmentId = action.payload
        }
    },
    extraReducers: (builder) => {
        builder.addCase(fetchEnvironmentWithVariables.fulfilled, (state, action) => {
            console.log('Fetched environments:', action.payload)
            return {
                ...state,
                environments: action.payload
            }
        })
        builder.addCase(fetchEnvironmentWithVariables.rejected, (_state, action) => {
            // Log the error to the console
            console.error('Failed to fetch environments:', action.error)
        })
        builder.addCase(updateEnvironmentName.fulfilled, (state, action) => {
            const automation = state.environments.find((automation) => automation.id === action.payload.environmentId)
            if (automation) {
                automation.name = action.payload.environmentName
            }
        })
        builder.addCase(updateVariable.fulfilled, (state, action) => {
            // Find the environment which contains the variable we want to update
            const environment = state.environments.find((environment) =>
                environment.variables.some((variable) => variable.id === action.payload.id)
            )

            if (environment) {
                // Find the variable within the located environment
                const variable = environment.variables.find((variable) => variable.id === action.payload.id)
                if (variable) {
                    // Update the variable's name and value
                    variable.name = action.payload.name
                    variable.value = action.payload.value
                }
            }
        })
    }
})

export const { setactiveEnvironmentId } = environmentsSlice.actions

export default environmentsSlice.reducer
