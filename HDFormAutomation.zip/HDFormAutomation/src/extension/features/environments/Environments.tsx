import React from 'react'
import { EnvironmentAndVariablesType } from '../../../constants/types'
import Environment from './Environment'

interface EnvironmentsProps {
    environments: EnvironmentAndVariablesType[]
}

const Environments = ({ environments }: EnvironmentsProps) => {
    const environmentList = () =>
        environments.map((environment) => {
            return <Environment key={environment.id} environment={environment} />
        })

    return (
        <table>
            <tbody>{environmentList()}</tbody>
        </table>
    )
}

export default Environments
