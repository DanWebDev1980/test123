/* global chrome */
import React, { useState } from 'react'
import { unwrapResult } from '@reduxjs/toolkit'
import { EnvironmentAndVariablesType } from '../../../constants/types'
import { useAppDispatch, useAppSelector } from '../../../store/hooks'
import { selectEnvironmentName } from '../../../store/selectors'
import { RootState } from '../../../store/store'
import DeleteIcon from '../../components/buttons/DeleteIcon'
import DownArrowIcon from '../../components/buttons/DownArrowIcon'
import DuplicateIcon from '../../components/buttons/DuplicateIcon'
import TextInput from '../../components/inputs/TextInput'
import {
    addEnvironment,
    deleteEnvironment,
    fetchEnvironmentWithVariables,
    updateEnvironmentName
} from '../../services/indexedDB/environments/environmentsAPI'
import { addEnvironmentVariable, addVariable, fetchVariables } from '../../services/indexedDB/variables/variablesAPI'
import Variables from '../variables/Variables'

interface EnvironmentProps {
    environment: EnvironmentAndVariablesType
}

const Environment = ({ environment }: EnvironmentProps) => {
    const environmentName = useAppSelector((state: RootState) => selectEnvironmentName(state, environment.id))

    const [open, setOpen] = useState(false)
    const dispatch = useAppDispatch()

    const variableHeaders = (
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Value</th>
            <th>Actions</th>
        </tr>
    )

    const updateEnvironment = async (e: React.ChangeEvent<HTMLInputElement>) => {
        await dispatch(
            updateEnvironmentName({
                environmentId: environment.id,
                environmentName: e.target.value
            })
        )
    }

    const duplicateEnvironment = async () => {
        const actionResult = await dispatch(
            addEnvironment({
                name: environment.name + '_new'
            })
        )
        const newEnvironment = unwrapResult(actionResult)
        if (newEnvironment) {
            for (const variable of environment.variables) {
                // Duplicate the variable
                const addVariableResult = await dispatch(
                    addVariable({
                        name: variable.name,
                        value: variable.value
                    })
                )
                const newVariable = unwrapResult(addVariableResult)

                // Link the duplicated variable to the new environment
                await dispatch(
                    addEnvironmentVariable({
                        environment_id: newEnvironment.id,
                        variable_id: newVariable.id,
                        variable_order: environment.variables.indexOf(variable) + 1
                    })
                )
            }
            dispatch(fetchEnvironmentWithVariables())
        }
    }

    const removeEnvironment = async () => {
        await dispatch(deleteEnvironment(environment.id))
        dispatch(fetchVariables())
        dispatch(fetchEnvironmentWithVariables())
    }

    const newVariable = async () => {
        const addVariableResult = await dispatch(
            addVariable({
                name: '',
                value: ''
            })
        )

        const newVariable = unwrapResult(addVariableResult)

        await dispatch(
            addEnvironmentVariable({
                environment_id: environment.id,
                variable_id: newVariable.id,
                variable_order: environment.variables.length + 1
            })
        )

        dispatch(fetchEnvironmentWithVariables())
        dispatch(fetchVariables())
    }

    // Change to update from local storage as message will fail on popup close

    return (
        <>
            <tr>
                <>
                    <TextInput value={environmentName} handleOnChange={(e) => updateEnvironment(e)} />
                    <button
                        className="button-positive-action-2 margin-left-auto"
                        onClick={() => duplicateEnvironment()}>
                        <DuplicateIcon />
                    </button>

                    <button className="button-negative" onClick={() => removeEnvironment()}>
                        <DeleteIcon />
                    </button>

                    <button className="button-info margin-right-5px" onClick={() => setOpen(!open)}>
                        <DownArrowIcon />
                    </button>
                </>
            </tr>
            {open && variableHeaders}
            {open && <Variables variables={environment.variables} />}
            {open && (
                <button className="button-positive-action-1" onClick={() => newVariable()}>
                    Create
                </button>
            )}
        </>
    )
}

export default Environment
