import { createSlice } from '@reduxjs/toolkit'
import { VariableType } from '../../../constants/types'
import { deleteVariable, fetchVariables, updateVariable } from '../../services/indexedDB/variables/variablesAPI'

type VariablesState = {
    activeVariableId: VariableType['id'] | null
    variables: VariableType[]
}

const initialState: VariablesState = {
    activeVariableId: null,
    variables: []
}

export const variablesSlice = createSlice({
    name: 'variables',
    initialState,
    reducers: {
        setActiveVariableId: (state, action) => {
            state.activeVariableId = action.payload
        }
    },
    extraReducers: (builder) => {
        builder.addCase(fetchVariables.fulfilled, (state, action) => {
            console.log('Fetched variables:', action.payload)
            return {
                ...state,
                variables: action.payload
            }
        })
        builder.addCase(fetchVariables.rejected, (_state, action) => {
            // Log the error to the console
            console.error('Failed to fetch variables:', action.error)
        })
        builder.addCase(updateVariable.fulfilled, (state, action) => {
            const updatedVariable = action.payload
            if (updatedVariable) {
                const updatedVariables = state.variables.map((step) =>
                    step.id === updatedVariable.id ? updatedVariable : step
                )
                return {
                    ...state,
                    variables: updatedVariables
                }
            }
            return state
        })
        builder.addCase(deleteVariable.fulfilled, (state, action) => {
            const stepId = action.payload
            if (stepId) {
                // Remove the step with the returned stepId from the state
                const updatedVariables = state.variables.filter((step) => step.id !== stepId)
                state.variables = updatedVariables
            }
            return state
        })
    }
})

export const { setActiveVariableId } = variablesSlice.actions

export default variablesSlice.reducer
