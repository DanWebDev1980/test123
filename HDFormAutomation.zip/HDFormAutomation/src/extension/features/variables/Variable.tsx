/* global chrome */
import React from 'react'
import { VariableType } from '../../../constants/types'
import { useAppDispatch } from '../../../store/hooks'
import DeleteIcon from '../../components/buttons/DeleteIcon'
import TextInput from '../../components/inputs/TextInput'
import { fetchEnvironmentWithVariables } from '../../services/indexedDB/environments/environmentsAPI'
import { deleteVariable, fetchVariables, updateVariable } from '../../services/indexedDB/variables/variablesAPI'

interface VariableProps {
    variable: VariableType
}

const Variable = ({ variable }: VariableProps) => {
    const dispatch = useAppDispatch()

    const updateVariableName = async (e: React.ChangeEvent<HTMLInputElement>) => {
        await dispatch(
            updateVariable({
                id: variable.id,
                name: e.target.value,
                value: variable.value
            })
        )
    }

    const updateVariableValue = async (e: React.ChangeEvent<HTMLInputElement>) => {
        await dispatch(
            updateVariable({
                id: variable.id,
                name: variable.name,
                value: e.target.value
            })
        )
    }

    const removeVariable = async () => {
        await dispatch(deleteVariable(variable.id))
        dispatch(fetchVariables())
        dispatch(fetchEnvironmentWithVariables())
    }

    return (
        <tr key={variable.id}>
            <td key={variable.id}>{variable.id}</td>
            <td key={variable.id}>
                <TextInput value={variable.name} handleOnChange={(e) => updateVariableName(e)} />
            </td>
            <td key={variable.id}>
                {' '}
                <TextInput value={variable.value?.toString()} handleOnChange={(e) => updateVariableValue(e)} />
            </td>

            <td key={variable.id}>
                <button className="button-negative" onClick={() => removeVariable()}>
                    <DeleteIcon />
                </button>
            </td>
        </tr>
    )
}

export default Variable
