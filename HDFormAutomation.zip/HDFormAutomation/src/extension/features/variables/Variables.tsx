import React from 'react'
import { VariableType } from '../../../constants/types'
import Variable from './Variable'

interface VariablesProps {
    variables: VariableType[]
}

const Variables = ({ variables }: VariablesProps) => {
    const variableList = () =>
        variables.map((variable) => {
            return <Variable key={variable.id} variable={variable} />
        })

    return (
        <table>
            <tbody>{variableList()}</tbody>
        </table>
    )
}

export default Variables
