import { createSlice } from '@reduxjs/toolkit'
import { EnvironmentType } from '../constants/types'

type ExtentionState = {
    isRecording: boolean
    currentPage: string
    currentApplication: string
    currentEnvironment: null | EnvironmentType
}

const initialState: ExtentionState = {
    isRecording: false,
    currentPage: '',
    currentApplication: 'None',
    currentEnvironment: null
}

const extensionSlice = createSlice({
    name: 'extension',
    initialState,
    reducers: {
        setExtensionIsRecording: (state, action) => {
            state.isRecording = action.payload
        },
        setCurrentPage: (state, action) => {
            state.currentPage = action.payload
        },
        setCurrentApplication: (state, action) => {
            state.currentApplication = action.payload
        },
        setCurrentEnvironment: (state, action) => {
            state.currentEnvironment = action.payload
        }
    }
})

export const { setExtensionIsRecording, setCurrentPage, setCurrentApplication, setCurrentEnvironment } =
    extensionSlice.actions

export default extensionSlice.reducer
