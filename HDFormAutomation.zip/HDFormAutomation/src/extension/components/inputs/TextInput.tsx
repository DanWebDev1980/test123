import React, { useRef } from "react";
interface TextInputProps {
    value: string;
    handleOnChange: (event: React.ChangeEvent<HTMLInputElement>) => Promise<void>;
    disabled?: boolean;
}

const TextInput = ({ value, handleOnChange, disabled }: TextInputProps) => {
    const inputRef = useRef<HTMLInputElement>(null);

    return (
        <input
            ref={inputRef}
            type='text'
            value={value}
            onChange={handleOnChange}
            disabled={disabled ? disabled : false}
        />
    )
}

export default React.memo(TextInput);
