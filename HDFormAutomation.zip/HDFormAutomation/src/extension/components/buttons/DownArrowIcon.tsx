import React from "react";

export const DownArrowIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24}>
        <path d="m12 18 3-6 3-5.993L12 6l-6 .007L8.997 12z" />
    </svg>
);

export default DownArrowIcon;