import React from "react";

export const RecordIcon = () => (
    <svg version="1.1" id="Controls" x="0px" y="0px" viewBox="0 0 24 24" xmlSpace="preserve" width="24" height="24"
        xmlns="http://www.w3.org/2000/svg">
        <defs id="defs56" />
        <style type="text/css" id="style30">
            {`.st0{display:none;fill:#1E1E1E;}
        .st1{fill:#1E1E1E;}`}
        </style>


        <g id="row1">
            <circle id="_x33__2_" className="st1" cx="12" cy="12" style={{ strokeWidth: '0.1875' }} r="12" />
            <polygon id="_x31_" className="st0" points="0,1 128,64 0,127 " />
        </g>
    </svg>
);

export default RecordIcon;