import React from "react";

export const PlayIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} >
        <title>{"Play"}</title>
        <path
            d="M12 0a12 12 0 1 0 12 12A12 12 0 0 0 12 0Zm4.468 12.661L9.543 16.66a.683.683 0 0 1-1.025-.592V8.071a.684.684 0 0 1 1.026-.592l6.924 3.998a.683.683 0 0 1 0 1.184z"
            data-name="Play"
        />
    </svg>
);

export default PlayIcon;