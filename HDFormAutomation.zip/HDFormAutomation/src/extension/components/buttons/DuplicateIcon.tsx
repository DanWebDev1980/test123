import React from "react";

export const DuplicateIcon = () => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        id="svg1796"
        width={24}
        height={24}
    >
        <defs id="defs1787">
            <style id="style1785">{".cls-1{fill:#0072ff}"}</style>
        </defs>
        <title id="title1789">{"Duplicate"}</title>
        <g
            id="Layer_2"
            data-name="Layer 2"
            transform="matrix(-.35714 0 0 .35714 23.429 .571)"
        >
            <rect
                id="rect1791"
                width={40}
                height={40}
                x={4}
                y={20}
                className="cls-1"
                rx={6.99}
                ry={6.99}
                style={{
                    fill: "#000",
                    fillOpacity: 1,
                }}
            />
            <path
                id="path1793"
                d="M53 4H27a7 7 0 0 0-7 7v1.86A3.14 3.14 0 0 0 23.14 16H37a11 11 0 0 1 11 11v13.86A3.14 3.14 0 0 0 51.14 44H53a7 7 0 0 0 7-7V11a7 7 0 0 0-7-7Z"
                className="cls-1"
                style={{
                    fill: "#000",
                    fillOpacity: 1,
                }}
            />
        </g>
    </svg>
);

export default DuplicateIcon;
