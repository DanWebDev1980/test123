/* global chrome */
import { IndexedDBHDAutomations } from '../../../constants/app'

const openDB = (): Promise<IDBDatabase> => {
    console.log('IDB -- openDB')
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(IndexedDBHDAutomations)
        request.onerror = () => reject('Error opening database')
        request.onsuccess = () => resolve(request.result)
    })
}

const getStore = (db: IDBDatabase, storeName: string, mode: IDBTransactionMode = 'readonly') => {
    console.log('IDB -- getStore', storeName, mode)
    const tx = db.transaction(storeName, mode)
    return tx.objectStore(storeName)
}

export const create = async (storeName: string, item: any) => {
    console.log('IDB -- create', storeName, item)
    const db = await openDB()
    const store = getStore(db, storeName, 'readwrite')
    return new Promise<void>((resolve, reject) => {
        const request: IDBRequest = store.add(item)
        request.onerror = (event) => reject(new Error(`Error adding item: ${(event.target as IDBRequest).error}`))
        request.onsuccess = () => resolve()
    })
}

export const createOrUpdate = async (storeName: string, item: any) => {
    console.log('IDB -- createOrUpdate', storeName, item)

    const db = await openDB()
    const store = getStore(db, storeName, 'readwrite')
    return new Promise<void>((resolve, reject) => {
        const request = store.put(item)
        request.onerror = (event) =>
            reject(new Error(`Error creating or updating item: ${(event.target as IDBRequest).error}`))
        request.onsuccess = () => resolve()
    })
}

export const readFirst = async (storeName: string, id: string) => {
    console.log('IDB -- readFirst', storeName, id)

    const db = await openDB()
    const store = getStore(db, storeName)
    const request = store.get(id)
    return new Promise<void>((resolve, reject) => {
        request.onerror = (event) =>
            reject(new Error(`Error reading first item: ${(event.target as IDBRequest).error}`))
        request.onsuccess = () => resolve(request.result)
    })
}

export const readAllByIndex = async (storeName: string, indexName: string) => {
    console.log('IDB -- readAllByIndex', storeName, indexName)

    const db = await openDB()
    const store = getStore(db, storeName)
    const index = store.index(indexName)
    const request = index.getAll()

    return new Promise<{ id: number; value: string }[]>((resolve, reject) => {
        request.onerror = (event) =>
            reject(new Error(`Error retrieving items by ${indexName}: ${(event.target as IDBRequest).error}`))
        request.onsuccess = (event) => {
            const data = (event.target as IDBRequest).result.map((value: Record<string, unknown>) => ({
                id: value.id,
                value: value
            }))
            resolve(data)
        }
    })
}

export const readAll = async (storeName: string) => {
    console.log('IDB -- readAll', storeName)

    const db = await openDB()
    const store = getStore(db, storeName)
    const request = store.getAll()
    return new Promise((resolve, reject) => {
        request.onerror = () => reject(new Error('Error reading all items'))
        request.onsuccess = () => resolve(request.result)
    })
}

export const update = async (storeName: string, id: any, updatedFields: Record<string, unknown>) => {
    console.log('IDB -- update', storeName, id, updatedFields)

    const db = await openDB()
    const store = getStore(db, storeName, 'readwrite')

    return new Promise<void>((resolve, reject) => {
        const getRequest = store.get(id)
        getRequest.onerror = () => reject(new Error(`Error finding item with id ${id}`))
        getRequest.onsuccess = () => {
            const existingItem = getRequest.result
            if (!existingItem) {
                return reject(new Error(`Item not found with id ${id}`))
            }

            const updatedItem = { ...existingItem, ...updatedFields }
            const putRequest = store.put(updatedItem)
            putRequest.onerror = () => reject(new Error(`Error updating item with id ${id}`))
            putRequest.onsuccess = () => resolve()
        }
    })
}

export const remove = async (storeName: string, id: string) => {
    console.log('IDB -- remove', storeName, id)

    const db = await openDB()
    const store = getStore(db, storeName, 'readwrite')
    return new Promise<void>((resolve, reject) => {
        const request = store.delete(id)
        request.onerror = () => reject(new Error('Error deleting item'))
        request.onsuccess = () => resolve()
    })
}

export const getStoreNames = async (): Promise<string[]> => {
    const db = await openDB()
    const storeNames = db.objectStoreNames
    return Array.from(storeNames)
}

export const getStoreColumns = async (storeName: string): Promise<string[]> => {
    console.log('IDB -- getStoreColumns', storeName)
    const db = await openDB()
    const store = getStore(db, storeName)
    const columns = store.indexNames
    console.log('IDB -- getStoreColumns', columns)
    return Array.from(columns)
}
