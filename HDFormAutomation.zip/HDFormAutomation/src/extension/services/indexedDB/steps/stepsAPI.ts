import { createAsyncThunk } from '@reduxjs/toolkit';
import { openDB } from 'idb';
import { IndexedDBHDAutomations } from '../../../../constants/app';
import { AddStepFormType, AddStepRequestType, AddStepScriptType, StepFormType, StepRequestType, StepScriptType, StepType } from '../../../../constants/types';


export const addStep = createAsyncThunk(
    'steps/addStep',
    async (newStep: AddStepRequestType | AddStepFormType | AddStepScriptType) => {
        let store
        if (newStep.step_type === 'request') {
            store = 'step_request'
        } else if (newStep.step_type === 'script') {
            store = 'step_script'
        } else if (newStep.step_type === 'form') {
            store = 'step_form'
        } else {
            store = null
        }
        if (!store) return

        const db = await openDB(IndexedDBHDAutomations, 1)
        const transaction = db.transaction(store, 'readwrite')
        const objectStore = transaction.objectStore(store)
        const newId = await objectStore.add(newStep)
        await transaction.done

        return { ...newStep, id: newId } as StepType
    }
)

type AddAutomationStepProps = {
    automation_id: number
    step_id: number
    step_order: number
}

export const addAutomationStep = createAsyncThunk(
    'steps/addAutomationStep',
    async (newStep: AddAutomationStepProps) => {
        console.log('newStep', newStep)
        const db = await openDB(IndexedDBHDAutomations, 1)
        const transaction = db.transaction('automation_step', 'readwrite')
        const objectStore = transaction.objectStore('automation_step')
        await objectStore.add(newStep)
        return newStep
    }
)

export const fetchSteps = createAsyncThunk('steps/fetchSteps', async () => {
    const db = await openDB(IndexedDBHDAutomations, 1)

    // Fetch steps from step_form table
    const stepFormTransaction = db.transaction('step_form', 'readonly')
    const stepFormStore = stepFormTransaction.objectStore('step_form')
    let stepFormSteps: StepFormType[] = await stepFormStore.getAll()
    await stepFormTransaction.done

    // Process element_attributes for each stepForm
    stepFormSteps = stepFormSteps.map((step) => {
        const attributesArray = []
        if (!step.element_attributes) {
            step.element_attributes = []
        } else if (typeof step.element_attributes === 'string') {
            const parsedAttributes = JSON.parse(step.element_attributes)
            for (const [key, value] of Object.entries(parsedAttributes)) {
                if (typeof value === 'string') {
                    const splitValues = value.split(':')
                    if (splitValues.every((val) => val === '')) {
                        continue
                    } else {
                        attributesArray.push(...splitValues.map((val) => ({ [key]: val })))
                    }
                }
            }
            step.element_attributes = attributesArray.length > 0 ? attributesArray : []
        }
        return step
    })

    // Fetch steps from step_request table
    const stepRequestTransaction = db.transaction('step_request', 'readonly')
    const stepRequestStore = stepRequestTransaction.objectStore('step_request')
    let stepRequestSteps: StepRequestType[] = await stepRequestStore.getAll()
    await stepRequestTransaction.done

    // Process step_request_headers for each stepRequest
    stepRequestSteps = stepRequestSteps.map((step) => {
        const headersArray = []

        // Process step_request_headers
        if (typeof step.step_request_headers === 'string') {
            const parsedHeaders = JSON.parse(step.step_request_headers)
            for (const [key, value] of Object.entries(parsedHeaders)) {
                if (typeof value === 'string') {
                    const splitValues = value.split(':')
                    if (!splitValues.every((val) => val === '')) {
                        headersArray.push(...splitValues.map((val) => ({ [key]: val })))
                    }
                }
            }
            step.step_request_headers = headersArray.length > 0 ? headersArray : []
        } else if (!step.step_request_headers) {
            step.step_request_headers = []
        }

        // Process step_body
        if (typeof step.step_body === 'string') {
            if (step.step_body.trim().startsWith('<')) {
                // It's an XML string
                step.step_body = [{ xml: step.step_body }]
            } else if (step.step_body.trim().startsWith('{')) {
                // It's a JSON string
                const parsedBody = JSON.parse(step.step_body)
                const bodyArray = []
                for (const [key, value] of Object.entries(parsedBody)) {
                    if (typeof value === 'string') {
                        bodyArray.push({ [key]: value })
                    }
                }
                step.step_body = bodyArray
            }
        } else if (step.step_body === null) {
            step.step_body = []
        }

        return step
    })

    // Fetch steps from step_script table
    const stepScriptTransaction = db.transaction('step_script', 'readonly')
    const stepScriptStore = stepScriptTransaction.objectStore('step_script')
    const stepScriptSteps: StepScriptType[] = await stepScriptStore.getAll()
    await stepScriptTransaction.done

    // Combine all steps into a single array (if this is your intention)
    const allSteps: StepType[] = [...stepFormSteps, ...stepRequestSteps, ...stepScriptSteps]

    return allSteps
})

export const updateStep = createAsyncThunk('steps/updateStep', async (step: StepType) => {
    console.log('updateStep API -- step: ', step)
    let store
    if (step.step_type === 'request') {
        store = 'step_request'
    } else if (step.step_type === 'script') {
        store = 'step_script'
    } else if (step.step_type === 'form') {
        store = 'step_form'
    } else {
        store = null
    }
    if (!store || !step.id) return

    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction(store, 'readwrite')
    const objectStore = transaction.objectStore(store)

    const existingStep = await objectStore.get(step.id)

    if (existingStep) {
        // Process based on step_type
        let stepToSave = { ...step } // Create a shallow copy

        if (step.step_type === 'form' && Array.isArray(stepToSave.element_attributes)) {
            stepToSave.element_attributes = JSON.stringify(stepToSave.element_attributes)
        }

        if (step.step_type === 'request') {
            if (Array.isArray(stepToSave.step_body) && stepToSave.step_body[0] && !stepToSave.step_body[0].xml) {
                stepToSave.step_body = JSON.stringify(stepToSave.step_body)
            }
            if (Array.isArray(stepToSave.step_request_headers)) {
                stepToSave.step_request_headers = JSON.stringify(stepToSave.step_request_headers)
            }
        }

        const updatedStep = { ...existingStep, ...stepToSave }

        await objectStore.put(updatedStep)
        await transaction.done
        return updatedStep
    }
    await transaction.done
    return null
})


export const deleteStep = createAsyncThunk('steps/deleteStep', async (step: StepType) => {
    let store
    if (step.step_type === 'request') {
        store = 'step_request'
    } else if (step.step_type === 'script') {
        store = 'step_script'
    } else if (step.step_type === 'form') {
        store = 'step_form'
    } else {
        store = null
    }
    if (!store || !step.id) return

    const db = await openDB(IndexedDBHDAutomations, 1)

    // Delete the step from the 'step' object store
    const stepTransaction = db.transaction(store, 'readwrite')
    const stepObjectStore = stepTransaction.objectStore(store)
    await stepObjectStore.delete(step.id)
    await stepTransaction.done

    // Delete the step from the 'automation_step' object store
    const automationStepTransaction = db.transaction('automation_step', 'readwrite')
    const automationStepObjectStore = automationStepTransaction.objectStore('automation_step')
    const stepIndex = automationStepObjectStore.index('step_id')
    let cursor = await stepIndex.openCursor(IDBKeyRange.only(step.id))
    while (cursor) {
        await automationStepObjectStore
            .delete(cursor.primaryKey)
            .catch((e) => console.log('Error deleting from automation_step: ', e))
        cursor = await cursor.continue()
    }
    await automationStepTransaction.done

    return step.id
})

export const moveStepUp = createAsyncThunk('steps/moveStepUp', async (stepId: number) => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    console.log('moveStepUp -stepId', stepId)
    try {
        // Get the step from the 'automation_step' object store
        const automationStepTransaction = db.transaction('automation_step', 'readwrite')
        const automationStepObjectStore = automationStepTransaction.objectStore('automation_step')
        const stepIndex = automationStepObjectStore.index('step_id')
        const step = await stepIndex.get(stepId)

        console.log('Retrieved step: ', step)

        // Check if the step is already at the lowest position
        if (step.step_order === 0) {
            console.log('Step is already at the lowest position.')
            return stepId
        }

        // Open a cursor to iterate over the steps in reverse order
        let cursor = await automationStepObjectStore.index('step_order').openCursor(null, 'prev')

        // Find the previous step in the order
        let previousStep
        while (cursor) {
            console.log('Checking step with order: ', cursor.value.step_order)
            if (cursor.value.step_order < step.step_order) {
                previousStep = cursor.value
                console.log('Found previous step: ', previousStep)
                break
            }
            cursor = await cursor.continue()
        }

        if (previousStep) {
            // Swap the step orders
            const tempStepOrder = previousStep.step_order
            previousStep.step_order = step.step_order
            step.step_order = tempStepOrder
            console.log('Swapped step orders: ', previousStep, step)

            // Update the step orders in the 'automation_step' object store
            await automationStepObjectStore.put(previousStep)
            await automationStepObjectStore.put(step)

            // Log the updated steps
            const updatedPreviousStep = await stepIndex.get(previousStep.step_id)
            const updatedStep = await stepIndex.get(stepId)
            console.log('Updated steps: ', updatedPreviousStep, updatedStep)
        }

        await automationStepTransaction.done

        return stepId
    } catch (e) {
        console.log('Error in moveStepUp: ', e)
    }
})

export const moveStepDown = createAsyncThunk('steps/moveStepDown', async (stepId: number) => {
    const db = await openDB(IndexedDBHDAutomations, 1)

    // Get the step from the 'automation_step' object store
    const automationStepTransaction = db.transaction('automation_step', 'readwrite')
    const automationStepObjectStore = automationStepTransaction.objectStore('automation_step')
    const stepIndex = automationStepObjectStore.index('step_id')
    const step = await stepIndex.get(stepId)
    console.log('Retrieved step: ', step)

    // Check if the step is already at the highest position
    const highestStepCursor = await automationStepObjectStore.index('step_order').openCursor(null, 'prev')
    if (!highestStepCursor || highestStepCursor.value.step_order === step.step_order) {
        console.log('Step is already at the highest position.')
        return stepId
    }

    // Open a cursor to iterate over the steps
    let cursor = await automationStepObjectStore.index('step_order').openCursor()

    // Find the next step in the order
    let nextStep
    while (cursor) {
        console.log('Checking step with order: ', cursor.value.step_order)
        if (cursor.value.step_order > step.step_order) {
            nextStep = cursor.value
            console.log('Found next step: ', nextStep)
            break
        }
        cursor = await cursor.continue()
    }

    if (nextStep) {
        // Swap the step orders
        const tempStepOrder = nextStep.step_order
        nextStep.step_order = step.step_order
        step.step_order = tempStepOrder
        console.log('Swapped step orders: ', nextStep, step)

        // Update the step orders in the 'automation_step' object store
        await automationStepObjectStore.put(nextStep)
        await automationStepObjectStore.put(step)

        // Log the updated steps
        const updatedNextStep = await stepIndex.get(nextStep.step_id)
        const updatedStep = await stepIndex.get(stepId)
        console.log('Updated steps: ', updatedNextStep, updatedStep)
    }

    await automationStepTransaction.done

    return stepId
})