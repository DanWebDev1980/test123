import { createAsyncThunk } from '@reduxjs/toolkit'
import { openDB } from 'idb'
import { IndexedDBHDAutomations } from '../../../../constants/app'
import { AddEnvironmentType, EnvironmentType } from '../../../../constants/types'

export const fetchEnvironmentWithVariables = createAsyncThunk(
    'environments/fetchEnvironmentWithVariables',
    async () => {
        const db = await openDB(IndexedDBHDAutomations, 1)

        const tx1 = db.transaction('environment', 'readonly')
        const environmentStore = tx1.objectStore('environment')
        const environments = await environmentStore.getAll()

        const tx2 = db.transaction('variable', 'readonly')
        const variableStore = tx2.objectStore('variable')
        const variables = await variableStore.getAll()

        const tx3 = db.transaction('environment_variable', 'readonly')
        const environmentVariableStore = tx3.objectStore('environment_variable')
        const environmentVariableData = await environmentVariableStore.getAll()

        const environmentsWithVariables = environments.map((environment) => {
            const environmentVariables = environmentVariableData
                .filter((item) => item.environment_id === environment.id)
                .sort((a, b) => a.variable_order - b.variable_order)
                .map((item) => {
                    const variable = variables.find((variable) => variable.id === item.variable_id)
                    return { ...variable, variable_order: item.variable_order }
                })

            return {
                ...environment,
                variables: environmentVariables
            }
        })

        return environmentsWithVariables
    }
)

export const updateEnvironmentName = createAsyncThunk(
    'environments/updateEnvironmentName',
    async ({ environmentId, environmentName }: { environmentId: number; environmentName: string }) => {
        const db = await openDB(IndexedDBHDAutomations, 1)
        const transaction = db.transaction('environment', 'readwrite')
        const objectStore = transaction.objectStore('environment')

        const environment = await objectStore.get(environmentId)
        environment.name = environmentName
        await objectStore.put(environment)
        return { environmentId, environmentName }
    }
)

export const addEnvironment = createAsyncThunk(
    'environments/addEnvironment',
    async (newEnvironment: AddEnvironmentType) => {
        const db = await openDB(IndexedDBHDAutomations, 1)
        const transaction = db.transaction('environment', 'readwrite')
        const objectStore = transaction.objectStore('environment')
        const environmentId = await objectStore.add(newEnvironment)
        return { id: environmentId, ...newEnvironment } as EnvironmentType
    }
)

export const deleteEnvironment = createAsyncThunk('environments/deleteEnvironment', async (environmentId: number) => {
    const db = await openDB(IndexedDBHDAutomations, 1)

    const tx1 = db.transaction('environment', 'readwrite')
    const environmentsStore = tx1.objectStore('environment')
    await environmentsStore.delete(environmentId)

    const tx2 = db.transaction('environment_variable', 'readwrite')
    const environmentVariableStore = tx2.objectStore('environment_variable')
    const environmentVariableIndex = environmentVariableStore.index('environment_id')
    let cursorEnvironmentVariables = await environmentVariableIndex.openCursor(IDBKeyRange.only(environmentId))
    let variableIds = []
    while (cursorEnvironmentVariables) {
        variableIds.push(cursorEnvironmentVariables.value.variable_id)
        await environmentVariableStore
            .delete(cursorEnvironmentVariables.primaryKey)
            .catch((e) => console.log('Error deleting from environment_variable: ', e))
        cursorEnvironmentVariables = await cursorEnvironmentVariables.continue()
    }

    const tx3 = db.transaction('variable', 'readwrite')
    const variableStore = tx3.objectStore('variable')
    for (let variableId of variableIds) {
        await variableStore.delete(variableId).catch((e) => console.log('Error deleting from variable: ', e))
    }

    return environmentId
})
