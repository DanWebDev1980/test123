import { update } from '../indexedDB'

export const addUserQuote = (userId: number, quoteRef: string | null) => {
    const item = {
        quote_ref: quoteRef
    }
    update('user', userId, item)
}
