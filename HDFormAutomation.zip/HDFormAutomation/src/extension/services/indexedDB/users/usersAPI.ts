import { createAsyncThunk } from '@reduxjs/toolkit'
import { openDB } from 'idb'
import { IndexedDBHDAutomations } from '../../../../constants/app'
import { AddUserType, UserType } from '../../../../constants/types'

// Define an async thunk that fetches users from IndexedDB
export const fetchUsers = createAsyncThunk('users/fetchUsers', async () => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction('user', 'readonly')
    const objectStore = transaction.objectStore('user')
    return await objectStore.getAll()
})

export const addUser = createAsyncThunk('users/addUser', async (newUser: AddUserType) => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction('user', 'readwrite')
    const objectStore = transaction.objectStore('user')
    const userId = await objectStore.add(newUser)
    return { ...newUser, id: userId } as UserType
})

export const deleteUser = createAsyncThunk('users/deleteUser', async (userId: number) => {
    const db = await openDB(IndexedDBHDAutomations, 1)

    const transaction1 = db.transaction('user', 'readwrite')
    const userStore = transaction1.objectStore('user')
    await userStore.delete(userId)

    const transaction2 = db.transaction('user_automation_step', 'readwrite')
    const userAutomationsStore = transaction2.objectStore('user_automation_step')
    const userAutomationsIndex = userAutomationsStore.index('user_id')
    let cursorUserAutomations = await userAutomationsIndex.openCursor(IDBKeyRange.only(userId))
    while (cursorUserAutomations) {
        await userAutomationsStore
            .delete(cursorUserAutomations.primaryKey)
            .catch((e) => console.log('Error deleting from user_automation_step: ', e))
        cursorUserAutomations = await cursorUserAutomations.continue()
    }

    return userId
})

export const updateUser = createAsyncThunk('users/updateUser', async (user: UserType) => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction('user', 'readwrite')
    const objectStore = transaction.objectStore('user')
    const existingUser = await objectStore.get(user.id)
    if (existingUser) {
        const updatedUser = { ...existingUser, ...user }
        await objectStore.put(updatedUser)
        await transaction.done
        return updatedUser
    }
    await transaction.done
    return null
})
