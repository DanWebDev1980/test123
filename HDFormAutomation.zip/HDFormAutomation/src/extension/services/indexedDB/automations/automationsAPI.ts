import { createAsyncThunk } from '@reduxjs/toolkit'
import { openDB } from 'idb'
import { IndexedDBHDAutomations, StepStatuses } from '../../../../constants/app'
import { AddAutomationType, AutomationType, GroupedUserAutomationSteps, UserAutomationType } from '../../../../constants/types'

export const fetchAutomationsWithSteps = createAsyncThunk('automations/fetchAutomationWithSteps', async () => {
    const db = await openDB(IndexedDBHDAutomations, 1)

    const tx1 = db.transaction('automation', 'readonly')
    const automationsStore = tx1.objectStore('automation')
    const automations = await automationsStore.getAll()

    const tx3 = db.transaction('automation_step', 'readonly')
    const automationStepsStore = tx3.objectStore('automation_step')
    const automationStepsData = await automationStepsStore.getAll()

    const tx4 = db.transaction('step_form', 'readonly')
    const stepFormStore = tx4.objectStore('step_form')
    const stepForms = await stepFormStore.getAll()

    const tx5 = db.transaction('step_request', 'readonly')
    const stepRequestStore = tx5.objectStore('step_request')
    const stepRequests = await stepRequestStore.getAll()

    const tx6 = db.transaction('step_script', 'readonly')
    const stepScriptStore = tx6.objectStore('step_script')
    const stepScripts = await stepScriptStore.getAll()

    const automationsWithSteps = automations.map((automation) => {
        const automationSteps = automationStepsData
            .filter((item) => item.automation_id === automation.id)
            .sort((a, b) => a.step_order - b.step_order)
            .map((item) => {
                let step
                if (item.step_type === 'form') {
                    step = stepForms.find((stepForm) => stepForm.id === item.step_id)

                    // Parse and process the step.element_attributes
                    const parsedAttributes = JSON.parse(step.element_attributes)
                    const attributesArray = []

                    if (typeof step.element_attributes === 'string') {
                        for (const [key, value] of Object.entries(parsedAttributes)) {
                            if (typeof value === 'string') {
                                const splitValues = value.split(':')
                                if (splitValues.every((val) => val === '')) {
                                    // If all values are empty strings, continue to the next iteration
                                    continue
                                } else {
                                    attributesArray.push(...splitValues.map((val) => ({ [key]: val })))
                                }
                            }
                        }
                    }

                    // Assign the attributesArray to step.element_attributes AFTER processing all entries
                    step.element_attributes = attributesArray.length > 0 ? attributesArray : []
                } else if (item.step_type === 'request') {
                    step = stepRequests.find((stepRequest) => stepRequest.id === item.step_id)
                    console.log(
                        'automationsAPI -- fetchAutomationsWithSteps -- step.step_request_headers:',
                        step.step_request_headers
                    )
                    console.log(
                        'automationsAPI -- fetchAutomationsWithSteps -- typeof(step.step_request_headers):',
                        typeof step.step_request_headers
                    )

                    // Parse and process the step_request_headers
                    const headersArray = []
                    if (typeof step.step_request_headers === 'string' || step.step_request_headers === 'object') {
                        if (typeof step.step_request_headers === 'string') {
                            step.step_request_headers = JSON.parse(step.step_request_headers)
                            console.log(
                                'automationsAPI -- fetchAutomationsWithSteps -- parsedHeaders:',
                                step.step_request_headers
                            )
                        }

                        if (Array.isArray(step.step_request_headers)) {
                            for (const obj of step.step_request_headers) {
                                for (const [key, value] of Object.entries(obj)) {
                                    if (typeof value === 'string' && value !== '') {
                                        headersArray.push({ [key]: value })
                                    }
                                }
                            }
                        }
                    }
                    console.log('automationsAPI -- fetchAutomationsWithSteps -- headersArray: ----', headersArray)
                    // Assign the headersArray to step_request_headers AFTER processing all entries
                    step.step_request_headers = headersArray.length > 0 ? headersArray : []
                } else if (item.step_type === 'script') {
                    step = stepScripts.find((stepScript) => stepScript.id === item.step_id)
                }

                return {
                    ...step,
                    step_order: item.step_order
                }
            })
        console.log('automationsAPI -- fetchAutomationsWithSteps -- automationSteps:', automationSteps)
        return {
            ...automation,
            steps: automationSteps
        }
    })

    return automationsWithSteps
})

export const fetchUserAutomations = async (userId: number) => {
    const db = await openDB(IndexedDBHDAutomations, 1)

    const tx1 = db.transaction('user_automation_step', 'readonly')
    const userAutomationsStore = tx1.objectStore('user_automation_step')
    const userAutomationsIndex = userAutomationsStore.index('user_id')
    const userAutomationSteps = await userAutomationsIndex.getAll(IDBKeyRange.only(userId))

    const tx2 = db.transaction('automation', 'readonly')
    const automationsStore = tx2.objectStore('automation')
    const automations = await automationsStore.getAll()

    const tx4 = db.transaction('automation_step', 'readonly')
    const automationStepsStore = tx4.objectStore('automation_step')
    const automationStepsData = await automationStepsStore.getAll()

    const tx5 = db.transaction('step_form', 'readonly')
    const stepFormStore = tx5.objectStore('step_form')
    const stepForms = await stepFormStore.getAll()

    const tx6 = db.transaction('step_request', 'readonly')
    const stepRequestStore = tx6.objectStore('step_request')
    const stepRequests = await stepRequestStore.getAll()

    const tx7 = db.transaction('step_script', 'readonly')
    const stepScriptStore = tx7.objectStore('step_script')
    const stepScripts = await stepScriptStore.getAll()

    // Group userAutomationSteps by automation_id
    const groupedUserAutomationSteps = userAutomationSteps.reduce((groups, userAutomationStep) => {
        const key = userAutomationStep.automation_id
        if (!groups[key]) {
            groups[key] = []
        }
        groups[key].push(userAutomationStep)
        return groups
    }, {})

    const userAutomationsWithSteps = (Object.values(groupedUserAutomationSteps) as GroupedUserAutomationSteps[][]).map(
        (userAutomationSteps: GroupedUserAutomationSteps[]) => {
            const automation = automations.find((automation) => automation.id === userAutomationSteps[0].automation_id)
            if (!automation) return {}
            
            console.log('automationsAPI -- fetchUserAutomations -- automation:', automation)
            
            const automationSteps = automationStepsData
                .filter((item) => item.automation_id === automation.id)
                .sort((a, b) => a.step_order - b.step_order)
                .map((item) => {
                    const stepType = item.step_type
                    let step
                    
                    if (stepType === 'form') {
                        step = stepForms.find((stepForm) => stepForm.id === item.step_id)

                        // Parse and process the step.element_attributes
                        const parsedAttributes = JSON.parse(step.element_attributes || '{}')
                        const attributesArray = []
                        
                        if (typeof step.element_attributes === 'string') {
                            for (const [key, value] of Object.entries(parsedAttributes)) {
                                if (typeof value === 'string') {
                                    const splitValues = value.split(':')
                                    if (!splitValues.every((val) => val === '')) {
                                        attributesArray.push(...splitValues.map((val) => ({ [key]: val })))
                                    }
                                }
                            }
                        }
                        
                        // Assign the attributesArray to step.element_attributes AFTER processing all entries
                        step.element_attributes = attributesArray.length > 0 ? attributesArray : []
                        
                    } else if (stepType === 'request') {
                        console.log('automationsAPI -- fetchUserAutomations -- stepRequest:', stepRequests)
                        console.log('automationsAPI -- fetchUserAutomations -- item.step_id:', item.step_id)
                        step = stepRequests.find((stepRequest) => stepRequest.id === item.step_id)
                        console.log('automationsAPI -- fetchUserAutomations -- step:', step)
                        // Parse and process the step_request_headers
                        const headersArray = []
                        if (typeof step.step_request_headers === 'string') {
                            step.step_request_headers = JSON.parse(step.step_request_headers)
                        }

                        if (Array.isArray(step.step_request_headers)) {
                            for (const obj of step.step_request_headers) {
                                for (const [key, value] of Object.entries(obj)) {
                                    if (typeof value === 'string' && value !== '') {
                                        headersArray.push({ [key]: value })
                                    }
                                }
                            }
                        }
                        
                        // Assign the headersArray to step_request_headers AFTER processing all entries
                        step.step_request_headers = headersArray.length > 0 ? headersArray : []
                        
                    } else if (stepType === 'script') {
                        step = stepScripts.find((stepScript) => stepScript.id === item.step_id)
                    }
                    
                    const userAutomationStep = userAutomationSteps.find((uas) => uas.step_id === item.step_id)
                    if (!userAutomationStep || !step) {
                        console.log('No step found for this item: ', item)
                        console.log('userAutomationSteps: ', userAutomationSteps)
                        console.log('userAutomationStep: ', userAutomationStep)
                        console.log('step: ', step)
                        return null
                    }
                    return {
                        ...step,
                        step_order: item.step_order,
                        step_run: userAutomationStep.step_run,
                        step_status: StepStatuses.STEP_READY,
                        step_run_error: ''
                    }
                })
                
            return {
                ...automation,
                user_id: userId,
                steps: automationSteps
            }
        }
    )

    return userAutomationsWithSteps
}

type AddUserAutomationProps = {
    user_id: number
    automation_id: number
}

export const addUserAutomation = createAsyncThunk(
    'automations/addUserAutomation',
    async (newAutomation: AddUserAutomationProps) => {
        console.log('newAutomation: ', newAutomation)

        const db = await openDB(IndexedDBHDAutomations, 1)

        // Get all steps associated with the automation
        const transaction1 = db.transaction('automation_step', 'readonly')
        const stepObjectStore = transaction1.objectStore('automation_step')
        const index = stepObjectStore.index('automation_id')
        const steps = await index.getAll(newAutomation.automation_id)

        // Now add a row for each step in the 'user_automation_step' table
        const transaction2 = db.transaction('user_automation_step', 'readwrite')
        const userAutomationStore = transaction2.objectStore('user_automation_step')
        console.log('steps:0----------------', steps)
        for (const step of steps) {
            const userAutomation: UserAutomationType = {
                user_id: newAutomation.user_id,
                automation_id: newAutomation.automation_id,
                step_id: step.step_id,
                step_type: step.step_type,
                step_run: true
            }

            await userAutomationStore.add(userAutomation)
        }

        return newAutomation
    }
)

type DeleteUserAutomationProps = {
    user_id: number
    automation_id: number
}

export const deleteUserAutomation = createAsyncThunk(
    'automations/deleteUserAutomation',
    async (automation: DeleteUserAutomationProps) => {
        const db = await openDB(IndexedDBHDAutomations, 1)

        const transaction = db.transaction('user_automation_step', 'readwrite')
        const userAutomationsStore = transaction.objectStore('user_automation_step')
        const userAutomationsIndex = userAutomationsStore.index('user_id')

        let cursorUserAutomations = await userAutomationsIndex.openCursor(IDBKeyRange.only(automation.user_id))
        while (cursorUserAutomations) {
            if (cursorUserAutomations.value.automation_id === automation.automation_id) {
                await userAutomationsStore
                    .delete(cursorUserAutomations.primaryKey)
                    .catch((e) => console.log('Error deleting from user_automation_step: ', e))
            }
            cursorUserAutomations = await cursorUserAutomations.continue()
        }

        return automation
    }
)

export const addAutomation = createAsyncThunk('automations/addAutomation', async (newAutomation: AddAutomationType) => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction('automation', 'readwrite')
    const objectStore = transaction.objectStore('automation')
    const automationId = await objectStore.add(newAutomation)
    return { id: automationId, ...newAutomation } as AutomationType
})

export const deleteAutomation = createAsyncThunk('automations/deleteAutomation', async (automationId: number) => {
    const db = await openDB(IndexedDBHDAutomations, 1)

    const tx1 = db.transaction('automation', 'readwrite')
    const automationsStore = tx1.objectStore('automation')
    await automationsStore.delete(automationId)

    const tx2 = db.transaction('user_automation_step', 'readwrite')
    const userAutomationsStore = tx2.objectStore('user_automation_step')
    const userAutomationsIndex = userAutomationsStore.index('automation_id')
    let cursorUserAutomations = await userAutomationsIndex.openCursor(IDBKeyRange.only(automationId))
    while (cursorUserAutomations) {
        await userAutomationsStore
            .delete(cursorUserAutomations.primaryKey)
            .catch((e) => console.log('Error deleting from user_automation_step: ', e))
        cursorUserAutomations = await cursorUserAutomations.continue()
    }

    const tx3 = db.transaction('automation_step', 'readwrite')
    const automationStepsStore = tx3.objectStore('automation_step')
    const automationStepsIndex = automationStepsStore.index('automation_id')
    let cursorAutomationSteps = await automationStepsIndex.openCursor(IDBKeyRange.only(automationId))
    let stepIds = []
    while (cursorAutomationSteps) {
        stepIds.push(cursorAutomationSteps.value.step_id)
        await automationStepsStore
            .delete(cursorAutomationSteps.primaryKey)
            .catch((e) => console.log('Error deleting from automation_step: ', e))
        cursorAutomationSteps = await cursorAutomationSteps.continue()
    }

    const tx4 = db.transaction('step_request', 'readwrite')
    const stepStoreRequest = tx4.objectStore('step_request')
    for (let stepId of stepIds) {
        await stepStoreRequest.delete(stepId).catch((e) => console.log('Error deleting from step: ', e))
    }

    const tx5 = db.transaction('step_script', 'readwrite')
    const stepStoreScript = tx5.objectStore('step_script')
    for (let stepId of stepIds) {
        await stepStoreScript.delete(stepId).catch((e) => console.log('Error deleting from step: ', e))
    }

    const tx6 = db.transaction('step_form', 'readwrite')
    const stepStoreForm = tx6.objectStore('step_form')
    for (let stepId of stepIds) {
        await stepStoreForm.delete(stepId).catch((e) => console.log('Error deleting from step: ', e))
    }

    return automationId
})

export const updateAutomationName = createAsyncThunk(
    'automations/updateAutomationName',
    async ({ automationId, automationName }: { automationId: number; automationName: string }) => {
        const db = await openDB(IndexedDBHDAutomations, 1)
        const transaction = db.transaction('automation', 'readwrite')
        const objectStore = transaction.objectStore('automation')

        const automation = await objectStore.get(automationId)
        automation.name = automationName
        await objectStore.put(automation)

        return { automationId, automationName }
    }
)

export const toggleUserAutomationRunStep = createAsyncThunk(
    'automations/toggleUserAutomationRunStep',
    async ({ automationId, userId, stepId }: { automationId: number; userId: number; stepId: number }) => {
        console.log('toggleUserAutomationRunStep: ', automationId, userId, stepId)
        const db = await openDB(IndexedDBHDAutomations, 1)
        const transaction = db.transaction('user_automation_step', 'readwrite')
        const objectStore = transaction.objectStore('user_automation_step')

        let cursor = await objectStore.openCursor()
        let updated = false
        let runStep = 'undefined'

        while (cursor) {
            if (
                cursor.value.user_id === userId &&
                cursor.value.automation_id === automationId &&
                cursor.value.step_id === stepId
            ) {
                let runStep = cursor.value.step_run // Declare runStep here
                cursor.value.step_run = !runStep // Toggle runStep
                if (runStep === 'undefined') {
                    runStep = !runStep
                }
                await objectStore.put(cursor.value)
                updated = true
            }
            cursor = await cursor.continue()
        }

        if (!updated) {
            throw new Error(`No step found for userId ${userId} and automationId ${automationId} and stepId ${stepId}`)
        }

        return { automationId, userId, runStep } // runStep is now definitely assigned if it's used
    }
)
