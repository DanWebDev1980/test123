import { createAsyncThunk } from '@reduxjs/toolkit'
import { openDB } from 'idb'
import { IndexedDBHDAutomations } from '../../../../constants/app'
import { VariableType } from '../../../../constants/types'

type AddVariableProps = {
    name: string
    value: string | boolean | number | [] | {}
}

export const addVariable = createAsyncThunk('variables/addVariable', async (newVariable: AddVariableProps) => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction('variable', 'readwrite')
    const objectStore = transaction.objectStore('variable')
    const newId = await objectStore.add(newVariable)
    await transaction.done
    return { ...newVariable, id: newId } as VariableType
})

type AddEnvironmentVariableProps = {
    environment_id: number
    variable_id: number
    variable_order: number
}

export const addEnvironmentVariable = createAsyncThunk(
    'variables/addEnvironmentVariable',
    async (newVariable: AddEnvironmentVariableProps) => {
        console.log('newVariable', newVariable)
        const db = await openDB(IndexedDBHDAutomations, 1)
        const transaction = db.transaction('environment_variable', 'readwrite')
        const objectStore = transaction.objectStore('environment_variable')
        await objectStore.add(newVariable)
        return newVariable
    }
)

export const fetchVariables = createAsyncThunk('variables/fetchVariables', async () => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction('variable', 'readonly')
    const objectStore = transaction.objectStore('variable')
    const variables: VariableType[] = await objectStore.getAll()
    await transaction.done
    return variables
})

export const updateVariable = createAsyncThunk('variables/updateVariable', async (variable: VariableType) => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction('variable', 'readwrite')
    const objectStore = transaction.objectStore('variable')
    const existingVariable = await objectStore.get(variable.id)
    if (existingVariable) {
        const updatedVariable = { ...existingVariable, ...variable }
        await objectStore.put(updatedVariable)
        await transaction.done
        return updatedVariable
    }
    await transaction.done
    return null
})

export const deleteVariable = createAsyncThunk('variables/deleteVariable', async (variableId: number) => {
    const db = await openDB(IndexedDBHDAutomations, 1)
    const transaction = db.transaction('variable', 'readwrite')
    const objectStore = transaction.objectStore('variable')
    const existingVariable = await objectStore.get(variableId)
    if (existingVariable) {
        await objectStore.delete(variableId)
        await transaction.done
    }

    const envTransaction = db.transaction('environment_variable', 'readwrite')
    const envObjectStore = envTransaction.objectStore('environment_variable')
    const envVariables = await envObjectStore.getAll()

    for (const envVariable of envVariables) {
        if (envVariable.variable_id === variableId) {
            await envObjectStore.delete(envVariable.id)
        }
    }

    await envTransaction.done
    return variableId
})

export const fetchVariable = createAsyncThunk(
    'variables/fetchVariable',
    async (variableId: number): Promise<VariableType> => {
        const db = await openDB(IndexedDBHDAutomations, 1)
        const transaction = db.transaction('variable', 'readonly')
        const objectStore = transaction.objectStore('variable')
        const variable: VariableType = await objectStore.get(variableId)
        await transaction.done
        return variable
    }
)
