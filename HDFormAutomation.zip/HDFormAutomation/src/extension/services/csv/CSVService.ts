import { saveAs } from 'file-saver'
import JSZip from 'jszip'
import Papa from 'papaparse'
import { IndexedDBHDAutomations } from '../../../constants/app'

export const loadCSV = async (url: string, storeName: string) => {
    let response = await fetch(url)
    let csvData = await response.text()

    let results = Papa.parse(csvData, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true
    })

    let openRequest = indexedDB.open(IndexedDBHDAutomations, 1)

    openRequest.onsuccess = function () {
        let db = openRequest.result

        let transaction = db.transaction(storeName, 'readwrite')
        let store = transaction.objectStore(storeName)

        for (let row of results.data) {
            store.put(row)
        }
    }

    openRequest.onerror = function () {
        console.error('Error opening database', openRequest.error)
    }
}

export const downloadCSVByStoreName = (storeName: string): Promise<string> => {
    return new Promise((resolve, reject) => {
        const openRequest = indexedDB.open(IndexedDBHDAutomations, 1)

        openRequest.onsuccess = function () {
            const db = openRequest.result
            const transaction = db.transaction(storeName, 'readonly')
            const store = transaction.objectStore(storeName)
            const data: Record<string, unknown>[] = []

            store.openCursor().onsuccess = function (event) {
                const cursor = (event.target as IDBRequest).result

                if (cursor) {
                    const record = cursor.value

                    // If element_attributes is an object, stringify it
                    if (typeof record.element_attributes === 'object' && record.element_attributes !== null) {
                        record.element_attributes = JSON.stringify(record.element_attributes)
                    }

                    data.push(record)
                    cursor.continue()
                } else {
                    const csvData = Papa.unparse(data)
                    resolve(csvData)
                }
            }
        }

        openRequest.onerror = function () {
            console.error('Error opening database', openRequest.error)
            reject(openRequest.error)
        }
    })
}

export const downloadAllStoresAsCSV = async () => {
    const openRequest = indexedDB.open(IndexedDBHDAutomations, 1)

    openRequest.onsuccess = async function () {
        const db = openRequest.result
        const zip = new JSZip()

        // Get an array of all object store names
        const storeNames = Array.from(db.objectStoreNames)

        // Iterate over the store names
        for (let storeName of storeNames) {
            // Fetch data and generate CSV for each store
            const csvData = await downloadCSVByStoreName(storeName) // assume this function now returns the CSV data as a string
            zip.file(`${storeName}.csv`, csvData)
        }

        // Generate and download the zip file
        zip.generateAsync({ type: 'blob' }).then((content) => {
            saveAs(content, 'stores.zip')
        })
    }
}
