import { ChangeEvent } from 'react'
import { loadCSV } from './CSVService'

export const loadCsvs = async (event: ChangeEvent<HTMLInputElement> | undefined) => {
    const files = event?.target.files

    if (!files) {
        console.error('No files selected')
        return
    }

    try {
        await Promise.all(
            Array.from(files).map((file) => {
                const fileUrl = URL.createObjectURL(file)
                return loadCSV(fileUrl, file.name.split('.')[0]) // Use the file name (minus the extension) as the store name
            })
        )
    } catch (error) {
        console.error('Error loading CSVs:', error)
    }
}
