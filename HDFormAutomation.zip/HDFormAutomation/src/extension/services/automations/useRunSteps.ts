/* global chrome */
import { v4 as uuidv4 } from 'uuid';
import { useCallback } from 'react';
import { StepStatuses } from '../../../constants/app';
import {
    AutomationType,
    StepFormType,
    StepRequestType,
    StepScriptType,
    StepType,
    UserType
} from '../../../constants/types'
import { useAppDispatch, useAppSelector } from '../../../store/hooks'
import { updateAutomationStep } from '../../features/automations/automationsSlice'
import { RootState } from '../../../store/store';

const useRunSteps = () => {
    const dispatch = useAppDispatch()
    const environment = useAppSelector((state: RootState) => state.extension.currentEnvironment)
    console.log('useRunSteps -- environment:', environment)

    const hydrateFormStep = (step: StepFormType, automation: AutomationType, user: UserType) => {
        console.log('useRunSteps -- hydrateFormStep -- user:', user)
        console.log('useRunSteps -- hydrateFormStep -- automation:', automation)
        console.log('useRunSteps -- hydrateFormStep -- step:', step)

        if (step.element_value_type === 'store' && step.element_value === 'quote_ref') {
            const quoteRef = user.quote_ref?.toString()
            return {
                ...step,
                element_value: quoteRef
            }
        } else {
            return step
        }
    }

    const hydrateRequestStep = (step: StepRequestType, automation: AutomationType, user: UserType) => {
        console.log('useRunSteps -- hydrateRequestStep -- user:', user)
        console.log('useRunSteps -- hydrateRequestStep -- automation:', automation)
        console.log('useRunSteps -- hydrateRequestStep -- step:', step)

        function mergeHeaders(headerArray: { [key: string]: string }[]): { [key: string]: string } {
            const headers: { [key: string]: string } = {}
            headerArray.forEach((headerObj) => {
                Object.keys(headerObj).forEach((key) => {
                    headers[key] = headerObj[key]
                })
            })
            return headers
        }

        function replaceTemplateStrings(template: string): string {
            return template.replace(/\{\{([^}]+)\}\}/g, (_match, variable) => {
                const [objectName, ...path] = variable.split('__')
                let currentValue: any
                console.log('useRunSteps -- hydrateRequestStep -- replaceTemplateStrings -- objectName:', objectName)
                switch (objectName) {
                    case 'user':
                        console.log('useRunSteps -- hydrateRequestStep -- replaceTemplateStrings -- user:', user)
                        currentValue = user
                        break
                    case 'automation':
                        console.log('useRunSteps -- hydrateRequestStep -- replaceTemplateStrings -- automation:', automation)
                        currentValue = automation
                        break
                    case 'environment':
                        console.log('useRunSteps -- hydrateRequestStep -- replaceTemplateStrings -- automation:', automation)
                        currentValue = environment
                        break
                        case 'function':
                        console.log('useRunSteps -- hydrateRequestStep -- replaceTemplateStrings -- function',...path);
                        currentValue = 'function'
                        break
                    default:
                        return _match // If the object name is unknown, return the original match
                }

                for (const property of path) {
                    if(currentValue === 'function') {
                        console.log('useRunSteps -- hydrateRequestStep -- replaceTemplateStrings -- function',property);
                        if(property === 'newUID') currentValue = uuidv4();
                    } else if (currentValue && typeof currentValue === 'object') {
                        currentValue = currentValue[property]
                    } else {
                        return _match // Return the original match if the path doesn't exist
                    }
                }

                return currentValue || _match // Return the resolved value or the original match if the value is falsy
            })
        }
        
        console.log('useRunSteps -- hydrateRequestStep -- step_request_pre_script:', step.step_request_pre_script)
        console.log('useRunSteps -- hydrateRequestStep -- Environment before pre script:', environment)
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            console.log('useRunSteps -- hydrateRequestStep -- chrome.runtime.onMessage.addListener -- sender:', sender)
            if (request.action === 'SCRIPT_EXECUTED') {
              if (request.success) {
                console.log('Script executed successfully:', request);
                // Update Environment variable with response
                store
: 
"environment"
value
: 
"2023-08-17"
variable
: 
"inception_date"
              } else {
                console.error('Script execution failed:', request.error);
              }
              
              // You can also send a response back to the content script if necessary
              sendResponse({ message: 'Received the script execution status' });
            }
          });
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            // Send a message to the content script in the active tab
            if (tabs[0].id)
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'RUN_PAGE_SCRIPT',
                    script: step.step_request_pre_script
                })
        })

        console.log('useRunSteps -- hydrateRequestStep -- Environment after pre script:', environment)
        const requestBody = replaceTemplateStrings(step.step_request_body)
        console.log('useRunSteps -- hydrateRequestStep -- requestBody:', requestBody)
        const newRequest = {
            url: step.step_request_url,
            body: requestBody,
            headers: mergeHeaders(step.step_request_headers),
            method: step.step_request_method
        }

        return newRequest
    }

    const hydrateScriptStep = (step: StepScriptType, automation: AutomationType, user: UserType) => {
        console.log('useRunSteps -- hydrateScriptStep -- user:', user)
        console.log('useRunSteps -- hydrateScriptStep -- automation:', automation)
        console.log('useRunSteps -- hydrateScriptStep -- step:', step)
    }

    interface RunStepResponse {
        success: boolean
        error?: string
    }
    const runSteps = useCallback(async (steps: StepType[], automation: AutomationType, user: UserType) => {
        console.log('useRunSteps -- runSteps', steps)
        console.log('useRunSteps -- runSteps -- automation', automation)
        console.log('useRunSteps -- runSteps -- user', user)

        for (let step of steps) {
            let shouldProceed = true // A flag to determine if the loop should proceed to the next step

            switch (step.step_type) {
                case 'form':
                    dispatch(
                        updateAutomationStep({
                            automationId: automation.id,
                            stepId: step.id,
                            field: 'step_status',
                            value: StepStatuses.STEP_RUNNING
                        })
                    )
                    const hydratedFormStep = hydrateFormStep(step, automation, user)
                    console.log('useRunSteps -- runSteps -- hydrated step: ', hydratedFormStep)

                    const resultForm = await new Promise<RunStepResponse>((resolve) => {
                        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                            chrome.runtime.sendMessage(
                                {
                                    action: 'runStep',
                                    tab: tabs[0],
                                    step: hydratedFormStep
                                },
                                (response) => {
                                    resolve(response)
                                }
                            )
                        })
                    })

                    if (resultForm.success) {
                        console.log('Step executed successfully')
                        dispatch(
                            updateAutomationStep({
                                automationId: automation.id,
                                stepId: step.id,
                                field: 'step_status',
                                value: StepStatuses.STEP_FINISHED
                            })
                        )
                    } else {
                        console.error('Error executing step:', resultForm.error)
                        shouldProceed = false // Set the flag to false if the step execution was not successful
                        dispatch(
                            updateAutomationStep({
                                automationId: automation.id,
                                stepId: step.id,
                                field: 'step_run_error',
                                value: JSON.stringify(resultForm.error)
                            })
                        )
                    }

                    // update state to finished or error
                    break
                case 'request':
                    const { url, body, headers, method } = hydrateRequestStep(step, automation, user)

                    const resultRequest = await new Promise<RunStepResponse>((resolve, reject) => {
                        chrome.runtime.sendMessage(
                            {
                                action: 'FETCH',
                                data: {
                                    url,
                                    body,
                                    headers,
                                    method
                                }
                            },
                            (response) => {
                                if (chrome.runtime.lastError) {
                                    // If there's an error sending the message, reject the promise
                                    reject(chrome.runtime.lastError)
                                } else {
                                    // If there's a response, resolve the promise with the response data
                                    resolve(response.data)
                                }
                            }
                        )
                    })

                    if (resultRequest.success) {
                        console.log('Step executed successfully')
                        dispatch(
                            updateAutomationStep({
                                automationId: automation.id,
                                stepId: step.id,
                                field: 'step_status',
                                value: StepStatuses.STEP_FINISHED
                            })
                        )
                    } else {
                        console.error('Error executing step:', resultRequest.error)
                        shouldProceed = false // Set the flag to false if the step execution was not successful
                        dispatch(
                            updateAutomationStep({
                                automationId: automation.id,
                                stepId: step.id,
                                field: 'step_run_error',
                                value: JSON.stringify(resultRequest.error)
                            })
                        )
                    }
                    break
                case 'script':
                    hydrateScriptStep(step, automation, user)
                    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                        // Send a message to the content script in the active tab
                        if (tabs[0].id)
                            chrome.tabs.sendMessage(tabs[0].id, {
                                action: 'RUN_PAGE_SCRIPT',
                                script: step.step_script
                            })
                    })
                    break
                default:
                    break
            }

            if (!shouldProceed) {
                break // Exit the loop if the flag is false
            }
        }
    }, [])

    return runSteps
}

export default useRunSteps