/* global chrome */

interface GWSetNewPassword {
    emailAddress: string
    dob: string
    passwordToken: string
    password: string
}

const gwSetNewPassword = async ({ emailAddress, dob, passwordToken, password }: GWSetNewPassword) => {
    const url = 'https://az-dev1.hastingsdirect.com/myaccount/account/account'

    const raw = JSON.stringify({
        id: '4',
        method: 'setNewPassword',
        params: [
            {
                EmailAddress: emailAddress,
                DateOfBirth: dob,
                brand: 'HD',
                passwordToken: passwordToken,
                newPassword: password,
                setVerified: true
            }
        ],
        jsonrpc: '2.0'
    })

    const headers = {
        Accept: '*/*',
        'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'Content-Type': 'application/json; charset=utf-8',
        'X-Requested-With': 'XMLHttpRequest'
    }

    const method = 'POST'
    console.log('raw', raw)
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
            {
                action: 'FETCH',
                data: {
                    url,
                    raw,
                    headers,
                    method
                }
            },
            (response) => {
                if (chrome.runtime.lastError) {
                    // If there's an error sending the message, reject the promise
                    reject(chrome.runtime.lastError)
                } else {
                    // If there's a response, resolve the promise with the response data
                    resolve(JSON.parse(response.data))
                }
            }
        )
    })
}

export default gwSetNewPassword
