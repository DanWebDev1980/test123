/* global chrome */
import { v4 as uuidv4 } from 'uuid';


interface CreatePHAddQuote {
    ph_inception_date: string
    ph_first_name: string
    ph_email: string
}

const createPHAddQuote = async ({ ph_inception_date, ph_first_name, ph_email }: CreatePHAddQuote) => {
    function generateInceptionDate() {
        if (!ph_inception_date) {
            const today = new Date()
            const dd = String(today.getDate()).padStart(2, '0')
            const mm = String(today.getMonth() + 1).padStart(2, '0')
            const yyyy = today.getFullYear()

            return yyyy + '-' + mm + '-' + dd
        }
        return ph_inception_date
    }

    const inceptionDate = generateInceptionDate()
    const session_UUID = uuidv4()
    const url =
        'https://dev1.test.hastings.local/pc/ws/com/hastings/integration/aggs/privatecar/qcore/PCQuoteEngineAPI/soap11'

    const raw = `
  <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soap="http://guidewire.com/ws/soapheaders" xmlns:pcq="http://HastingsDirect.com/qcore/PCQuoteEngineAPI">
  <soapenv:Body>
     <pcq:getAggregatorCarQuote>
        <!--Optional:-->
        <pcq:req>
           <CarQuoteRequest>
              <quoteHeader>
                 <aggsSource>InsurerGroup</aggsSource>
                 <aggsId>${session_UUID}</aggsId>
                 <timestamp>2018-07-19T09:00:00</timestamp>
                 <originOfBusiness>InsurerDefaultCampaign</originOfBusiness>
                 <headerAdditionalData>
                    <data>
                       <name>test1</name>
                       <value>test2</value>
                    </data>
                 </headerAdditionalData>
                 <systemDetails>
                    <operatingSystem>IOS 7.0.2</operatingSystem>
                    <browser>Safari</browser>
                    <ipAddress>192.15.42.15.9</ipAddress>
                    <browserVersion>9</browserVersion>
                    <browserLanguage>English UK</browserLanguage>
                    <ispCustomer>BT</ispCustomer>
                    <deviceType>iPhone 6s</deviceType>
                    <deviceManufacture>Apple</deviceManufacture>
                    <screenResolution>1080</screenResolution>
                    <geographicalLocation>test7</geographicalLocation>
                    <googleAnalyticsUserAge>test8</googleAnalyticsUserAge>
                    <googleAnalyticsGooglePersona>test9</googleAnalyticsGooglePersona>
                    <googleAnalyticsOriginalChannel>test10</googleAnalyticsOriginalChannel>
                    <googleAnalyticsNumOfDiffDevices>test11</googleAnalyticsNumOfDiffDevices>
                    <googleAnalyticsFrequencyOfVisits>test12</googleAnalyticsFrequencyOfVisits>
                 </systemDetails>
              </quoteHeader>
              <carQuote>
                 <autoRenewal>false</autoRenewal>
                 <marketingPermissions>false</marketingPermissions>
                 <noOfCarsHousehold>1</noOfCarsHousehold>
                 <noOfDriversinHouse typeListName="NoOfDrivers_Ext">
                    <noOfDriversinHouse>1</noOfDriversinHouse>
                 </noOfDriversinHouse>
                 <inceptionDate>${inceptionDate}</inceptionDate>
                 <car>
                    <abiCode>32120102</abiCode>
                    <registration>AV12BGE</registration>
                    <make>MERCEDES-BENZ</make>
                    <IsCarFitWithAEB>false</IsCarFitWithAEB>
                    <motDue typeListName="Months">
                       <motDue>january</motDue>
                    </motDue>
                    <bodyType>02</bodyType>
                    <yearOfRegistration>2012</yearOfRegistration>
                    <transmission typeListName="Transmission_Ext">
                       <transmission>001</transmission>
                    </transmission>
                    <engineSize>2143</engineSize>
                    <model>E250 SPORT ED125co CDI BLUE</model>
                    <noOfDoors>4</noOfDoors>
                    <noOfSeats>5</noOfSeats>
                    <fuelType>Diesel</fuelType>
                    <carValue>3300</carValue>
                    <purchaseDate>2014-03-05</purchaseDate>
                    <importType typeListName="ImportType_Ext">
                       <importType>no</importType>
                    </importType>
                    <importTypeDesc>send original description</importTypeDesc>
                    <rightHandDrive>true</rightHandDrive>
                    <immobiliser typeListName="AlarmImmobiliser_Ext">
                       <immobiliser>94</immobiliser>
                    </immobiliser>
                    <immobiliserDesc>After market immobiliser</immobiliserDesc>
                    <alarmDesc>After market Thatham alarm</alarmDesc>
                    <tracker>true</tracker>
                    <trackerDesc>GPS Tracker</trackerDesc>
                    <overnightPostCode>TA51BW</overnightPostCode>
                    <parkedDaytimeData>
                       <code>E</code>
                       <description>Work car park</description>
                    </parkedDaytimeData>
                    <parkedOvernight typeListName="KeptOvernight_Ext">
                       <parkedOvernight>F</parkedOvernight>
                    </parkedOvernight>
                    <parkedOvernightDesc>Public Car Park</parkedOvernightDesc>
                    <owner typeListName="OwnerKeeper_Ext">
                       <owner>1_PR</owner>
                    </owner>
                    <ownerDesc>Original owner value, e.g. proposer</ownerDesc>
                    <registeredKeeper typeListName="OwnerKeeper_Ext">
                       <registeredKeeper>1_PR</registeredKeeper>
                    </registeredKeeper>
                    <registeredKeeperDesc>Original registered keeper value, e.g. proposer</registeredKeeperDesc>
                    <cover>
                       <coverType typeListName="CoverageCategory_Ext">
                          <coverType>comprehensive</coverType>
                       </coverType>
                       <coverLevelDesc>cover type values</coverLevelDesc>
                       <classOfUse typeListName="ClassOfUse_Ext">
                          <classOfUse>01</classOfUse>
                       </classOfUse>
                       <classOfUseDesc>class of use values</classOfUseDesc>
                       <voluntaryExcess typeListName="VolExcess_Ext">
                          <voluntaryExcess>250</voluntaryExcess>
                       </voluntaryExcess>
                       <voluntaryExcessDesc>voluntary values</voluntaryExcessDesc>
                       <mainUser>1</mainUser>
                       <businessMileage>1000</businessMileage>
                       <personalMileage>8000</personalMileage>
                       <totalMileage>9000</totalMileage>
                       <ncdGrantedYears typeListName="NCDGrantedYears_Ext">
                          <ncdGrantedYears>6</ncdGrantedYears>
                       </ncdGrantedYears>
                       <ncdGreaterZero>
                          <ncdProtect>true</ncdProtect>
                          <ncdCurrentlyProtected>false</ncdCurrentlyProtected>
                          <howNcdEarn typeListName="NCDEarnedFrom_Ext">
                             <howNcdEarn>11</howNcdEarn>
                          </howNcdEarn>
                          <howNcdEarnDesc>Original description, e.g. Private Car Bonus</howNcdEarnDesc>
                          <ncdEarnedUk>true</ncdEarnedUk>
                       </ncdGreaterZero>
                       <!--<ncdZero>-->
                       <!--<nameDriverExpFlag>false</nameDriverExpFlag>-->
                       <!--<nameDriverExp typeListName="DrivingExperience_Ext">-->
                       <!--<nameDriverExp>21</nameDriverExp>-->
                       <!--</nameDriverExp>-->
                       <!--<yearsNamedDriverExp typeListName="NCD_Ext">-->
                       <!--<yearsNamedDriverExp>1</yearsNamedDriverExp>-->
                       <!--</yearsNamedDriverExp>-->
                       <!--<nameDriverExpDesc>named driver values</nameDriverExpDesc>-->
                       <!--</ncdZero>-->
                       <insurancePaymentType typeListName="InsurancePaymentType_Ext">
                          <insurancePaymentType>1</insurancePaymentType>
                       </insurancePaymentType>
                       <previousPolicyExpire>2015-11-09</previousPolicyExpire>
                       <!--<previousInsuranceProvider>test</previousInsuranceProvider>-->
                    </cover>
                 </car>
                 <drivers>
                    <policyholder>
                       <name>
                          <fullName>
                             <title typeListName="NamePrefix">
                                <title>003_Mr</title>
                             </title>
                             <titleDesc>Mr</titleDesc>
                             <firstName>${ph_first_name}</firstName>
                             <lastName>Forrest</lastName>
                          </fullName>
                       </name>
                       <driverId>1</driverId>
                       <dateOfBirth>1968-09-04</dateOfBirth>
                       <maritalStatus typeListName="MaritalStatus">
                          <maritalStatus>M</maritalStatus>
                       </maritalStatus>
                       <maritalStatusDesc>married - marital status values</maritalStatusDesc>
                       <address>
                          <addressLine1>1734 Bernard Street</addressLine1>
                          <addressLine2>Spaxton</addressLine2>
                          <addressLine3/>
                          <town></town>
                          <county>ELY</county>
                          <postCode>CB6 1AU</postCode>
                       </address>
                       <ukResident>1968-09-04</ukResident>
                       <marketingPreference>
                          <homeOwner>true</homeOwner>
                          <homeInsuranceRenewal typeListName="InsuranceRenewalMonth_Ext">
                             <homeInsuranceRenewal>march</homeInsuranceRenewal>
                          </homeInsuranceRenewal>
                          <timeAtCurrentAddress typeListName="NCDGrantedYears_Ext">
                             <timeAtCurrentAddress>4</timeAtCurrentAddress>
                          </timeAtCurrentAddress>
                          <anyChildrenUnder16>false</anyChildrenUnder16>
                          <tescoClubCardDetails>?</tescoClubCardDetails>
                          <fieldsData>
                             <code>test</code>
                             <value>test</value>
                          </fieldsData>
                       </marketingPreference>
                       <employment>
                          <isPrimary>true</isPrimary>
                          <employmentStatusCode typeListName="FullTimeEmpStatus_Ext">
                             <employmentStatusCode>E</employmentStatusCode>
                          </employmentStatusCode>
                          <employmentStatusDesc>status values</employmentStatusDesc>
                          <employmentOccupationCode typeListName="OccupationType_Ext">
                             <employmentOccupationCode>A01</employmentOccupationCode>
                          </employmentOccupationCode>
                          <employmentOccupationDesc>occupation values</employmentOccupationDesc>
                          <whatWereYouStudying>science</whatWereYouStudying>
                          <employmentBusinessCode typeListName="BusinessType_Ext">
                             <employmentBusinessCode>001</employmentBusinessCode>
                          </employmentBusinessCode>
                          <employmentBusinessDesc>business values</employmentBusinessDesc>
                       </employment>
                       <employment>
                          <isPrimary>false</isPrimary>
                          <employmentStatusCode typeListName="FullTimeEmpStatus_Ext">
                             <employmentStatusCode>E</employmentStatusCode>
                          </employmentStatusCode>
                          <employmentStatusDesc>Put original marital status description from partner site, e.g. self employed</employmentStatusDesc>
                          <employmentOccupationCode typeListName="OccupationType_Ext">
                             <employmentOccupationCode>D93</employmentOccupationCode>
                          </employmentOccupationCode>
                          <employmentOccupationDesc>Put original marital status description from partner site, e.g. accountant</employmentOccupationDesc>
                          <employmentBusinessCode typeListName="BusinessType_Ext">
                             <employmentBusinessCode>077</employmentBusinessCode>
                          </employmentBusinessCode>
                          <employmentBusinessDesc>Put original marital status description from partner site, e.g. accountancy</employmentBusinessDesc>
                       </employment>
                       <licence>
                          <number/>
                          <type typeListName="LicenceType_Ext">
                             <type>F_FM</type>
                          </type>
                          <typeDesc>licencetype values</typeDesc>
                          <lengthHeld>2014-08-27</lengthHeld>
                          <fullUkLicenceIamCert>false</fullUkLicenceIamCert>
                          <yearPassPlusCert>false</yearPassPlusCert>
                       </licence>
                       <myLicenceIndicator>false</myLicenceIndicator>
                       <useOtherVehicle typeListName="AccessOtherVeh_Ext">
                          <useOtherVehicle>no</useOtherVehicle>
                       </useOtherVehicle>
                       <useOtherVehicleDesc>useother values</useOtherVehicleDesc>
                       <primaryEmail>${ph_email}</primaryEmail>
                       <secondaryEmail>sample@email.con</secondaryEmail>
                       <homePhoneNumber/>
                       <workPhoneNumber/>
                       <mobilePhoneNumber/>
                       <faxPhoneNumber/>
                       <primaryPhone>home</primaryPhone>
                       <medicalConditions typeListName="DVLAMedicalCondition_Ext">
                          <medicalConditions>99_NO</medicalConditions>
                       </medicalConditions>
                       <medicalConditionsDesc>No</medicalConditionsDesc>
                       <nonMotoringConvictions>false</nonMotoringConvictions>
                       <isPolicyDeclinedForDrivers>false</isPolicyDeclinedForDrivers>
                       <regularlyDriveAtPeakTimes>true</regularlyDriveAtPeakTimes>
                    </policyholder>
                 </drivers>
                 <extraQuestions>
                    <vanInsured>false</vanInsured>
                    <renewalVanDue>2014-04-01</renewalVanDue>
                    <bikeInsured>false</bikeInsured>
                    <renewalBikeDue>2014-04-01</renewalBikeDue>
                    <homeInsured>false</homeInsured>
                    <renewalPrice>204</renewalPrice>
                    <bestPrice>304</bestPrice>
                 </extraQuestions>
                 <additionalVariablesString>
                    <question>
                       <id>5</id>
                       <value>test</value>
                    </question>
                 </additionalVariablesString>
                 <additionalVariablesDate>
                    <question>
                       <id>2</id>
                       <value>2014-04-01</value>
                    </question>
                 </additionalVariablesDate>
                 <additionalVariablesInteger>
                    <question>
                       <id>1</id>
                       <value>5</value>
                    </question>
                 </additionalVariablesInteger>
                 <additionalVariablesBoolean>
                    <question>
                       <id>1</id>
                       <value>true</value>
                    </question>
                 </additionalVariablesBoolean>
                 <ancillaries>
                    <ancillary>true</ancillary>
                    <ancillaryCode>1</ancillaryCode>
                 </ancillaries>
              </carQuote>
           </CarQuoteRequest>
        </pcq:req>
     </pcq:getAggregatorCarQuote>
  </soapenv:Body>
</soapenv:Envelope>
`

    const headers = {
        Accept: '*/*',
        'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'Content-Type': 'text/xml;charset=utf-8',
        'X-Requested-With': 'XMLHttpRequest'
    }

    const method = 'POST'

    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
            {
                action: 'FETCH',
                data: {
                    url,
                    raw,
                    headers,
                    method
                }
            },
            (response) => {
                if (chrome.runtime.lastError) {
                    // If there's an error sending the message, reject the promise
                    reject(chrome.runtime.lastError)
                } else {
                    // If there's a response, resolve the promise with the response data
                    resolve(response.data)
                }
            }
        )
    })
}

export default createPHAddQuote