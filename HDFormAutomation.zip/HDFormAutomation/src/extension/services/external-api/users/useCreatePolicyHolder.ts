import { UserType } from '../../../../constants/types'
import { useAppDispatch } from '../../../../store/hooks'
import { setActiveUserId, updateUserCreatedAt, updateUserCreatedError } from '../../../features/users/usersSlice'
import { addUserQuote } from '../../indexedDB/users/addUserQuote'
import { updateLoading } from '../externalAPISlice'
import createPHAddQuote from '../guide-wire/createPHAddQuote'

const useCreatePolicyHolder = (user: UserType) => {
    const dispatch = useAppDispatch()

    const createUser = async () => {
        console.log('createUser', user.id)
        dispatch(setActiveUserId(user.id))
        dispatch(updateLoading(true))
        try {
            const newQuote = (await createPHAddQuote({
                ph_inception_date: user.ph_inception_date,
                ph_first_name: user.ph_first_name,
                ph_email: user.ph_email
            })) as string

            dispatch(updateLoading(false))
            const parser = new DOMParser()
            const xmlDoc = parser.parseFromString(newQuote, 'text/xml')

            const quoteReference = xmlDoc.getElementsByTagName('quoteReference')[0].childNodes[0].nodeValue

            // store to db
            if (quoteReference) {
                addUserQuote(user.id, quoteReference)
                dispatch(updateUserCreatedAt({ id: user.id, createdAt: new Date().toISOString() }))
                dispatch(updateUserCreatedError({ id: user.id, createdError: '' }))
            }
        } catch (error) {
            dispatch(updateUserCreatedError({ id: user.id, createdError: error }))
            dispatch(updateUserCreatedAt({ id: user.id, createdAt: '' }))
            addUserQuote(user.id, null)
            dispatch(updateLoading(false))
        }
    }

    return createUser
}

export default useCreatePolicyHolder
