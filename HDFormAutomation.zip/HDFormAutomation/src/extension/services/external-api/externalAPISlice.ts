import { createSlice } from '@reduxjs/toolkit'

type ExternalAPIState = {
    createPHAddQuote: {
        loading: boolean
        error: any
    }
}

const initialState: ExternalAPIState = {
    createPHAddQuote: {
        loading: false,
        error: null
    }
}

const externalAPISlice = createSlice({
    name: 'external-api',
    initialState,
    reducers: {
        updateLoading: (state, action) => {
            console.log('externalAPISlice -- updateLoading', action.payload)
            state.createPHAddQuote.loading = action.payload
        }
    }
})

// Action creators are generated for each case reducer function
export const { updateLoading } = externalAPISlice.actions

export default externalAPISlice.reducer
