import React, { useEffect, useRef, useState } from 'react'
import { PAGES } from '../../constants/app'
import { useAppDispatch, useAppSelector } from '../../store/hooks'
import { RootState } from '../../store/store'
import { setCurrentApplication, setCurrentEnvironment, setCurrentPage } from '../extensionSlice'
import { downloadAllStoresAsCSV } from '../services/csv/CSVService'

const NavigationMenu = () => {
    const dispatch = useAppDispatch()
    const [isBurgerOpen, setIsBurgerOpen] = useState(false)
    const navigationRef = useRef<HTMLUListElement>(null)
    const currentApplication = useAppSelector((state: RootState) => state.extension.currentApplication)
    const currentEnvironment = useAppSelector((state: RootState) => state.extension.currentEnvironment?.name)
    const environments = useAppSelector((state: RootState) => state.environments.environments)

    const environmentOptions = environments.map((environment) => {
        return <option value={environment.name}>{environment.name}</option>
    })
    const setPage = (page: string) => {
        dispatch(setCurrentPage(page))
    }

    const setApplication = (application: string) => {
        dispatch(setCurrentApplication(application))
    }

    const setEnvironment = (environment: string) => {
        const currentEnvironment  = environments.find((env) => env.name === environment)
        dispatch(setCurrentEnvironment(currentEnvironment))
    }

    useEffect(() => {
        document.addEventListener('click', handleClickOutside)

        return () => {
            document.removeEventListener('click', handleClickOutside)
        }
    }, [])

    const handleClickOutside = (event: MouseEvent) => {
        if (navigationRef.current && !navigationRef.current.contains(event.target as Node)) {
            setIsBurgerOpen(false)
        }
    }

    const toggleBurgerMenu = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
        e.stopPropagation()
        setIsBurgerOpen(!isBurgerOpen)
    }

    return (
        <>
            <nav className="col-1">
                <div className={`burger-menu ${isBurgerOpen ? 'open' : ''}`} onClick={(e) => toggleBurgerMenu(e)}>
                    <div className={`burger-line ${isBurgerOpen ? 'open' : ''}`}></div>
                    <div className={`burger-line ${isBurgerOpen ? 'open' : ''}`}></div>
                    <div className={`burger-line ${isBurgerOpen ? 'open' : ''}`}></div>
                </div>
                <ul ref={navigationRef} className={`nav-links ${isBurgerOpen ? 'open' : ''}`}>
                    <li onClick={() => setPage(PAGES.ENVIRONMENTS)}>Environments</li>
                    <li onClick={() => setPage(PAGES.USER_ACCOUNTS)}>User Accounts</li>
                    <li onClick={() => setPage(PAGES.AUTOMATIONS)}>Automations</li>
                    <li onClick={() => document.getElementById('csv-file-input')?.click()}>Import</li>
                    <li onClick={() => downloadAllStoresAsCSV()}>Download</li>
                </ul>
            </nav>
            <select name="application" onChange={(e) => setApplication(e.target.value)} value={currentApplication}>
                <option value="None">Select Application</option>
                <option value="MTA">MTA</option>
                <option value="GW">GW</option>
            </select>
            <select name="application" onChange={(e) => setEnvironment(e.target.value)} value={currentEnvironment}>
                <option value="None">Select Environment</option>
                {environmentOptions}
            </select>
        </>
    )
}

export default NavigationMenu
