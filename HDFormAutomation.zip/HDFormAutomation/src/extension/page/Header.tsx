import React from 'react'
import HDLogo from '../../assets/HDLogo.png'
import { loadCsvs } from '../services/csv/loadCsvs'
import NavigationMenu from './NavigationMenu'

const Header = () => {
    return (
        <header>
            <div className="header-top-row-container">
                <input
                    type="file"
                    id="csv-file-input"
                    hidden
                    multiple
                    accept=".csv"
                    onChange={(event) => loadCsvs(event)}
                />

                <NavigationMenu />
                <div className="col-2">
                    <img src={HDLogo} alt="HD logo" />
                    <h1>Automation</h1>
                </div>
                <div className="col-3"></div>
            </div>
        </header>
    )
}

export default Header
