import React, { useEffect } from 'react';
import './App.css'
import { PAGES } from './constants/app'
import { StepFormType, StepRequestType, StepScriptType } from './constants/types'
import Automations from './extension/features/automations/Automations'
import Environments from './extension/features/environments/Environments'
import useRecording from './extension/features/record/useRecord'
import StepFormEdit from './extension/features/steps/StepFormEdit'
import StepRequestEdit from './extension/features/steps/StepRequestEdit'
import StepScriptEdit from './extension/features/steps/StepScriptEdit'
import UserEdit from './extension/features/users/UserEdit'
import Users from './extension/features/users/Users'
import Header from './extension/page/Header'
import { addAutomation, fetchAutomationsWithSteps } from './extension/services/indexedDB/automations/automationsAPI'
import {
    addEnvironment,
    fetchEnvironmentWithVariables
} from './extension/services/indexedDB/environments/environmentsAPI'
import { fetchSteps } from './extension/services/indexedDB/steps/stepsAPI'
import { addUser, fetchUsers } from './extension/services/indexedDB/users/usersAPI'
import { fetchVariables } from './extension/services/indexedDB/variables/variablesAPI'
import { useAppDispatch, useAppSelector } from './store/hooks'
import { selectStepById, selectUserById } from './store/selectors'
import { RootState } from './store/store'


function App() {
    const { checkIfRecording } = useRecording()
    const page = useAppSelector((state: RootState) => state.extension.currentPage)
    const users = useAppSelector((state: RootState) => state.users.users)
    const automations = useAppSelector((state: RootState) => state.automations.automations)
    const environments = useAppSelector((state: RootState) => state.environments.environments)

    const dispatch = useAppDispatch()

    const currentUserId = useAppSelector((state: RootState) => state.users.activeUserId)
    const currentStepId = useAppSelector((state: RootState) => state.steps.activeStepId)
    const currentAutomationId = useAppSelector((state: RootState) => state.automations.activeAutomationId)
    const currentStepForm = useAppSelector(
        (state: RootState) =>
            currentStepId && currentAutomationId && selectStepById(state, currentStepId, currentAutomationId, 'form')
    ) as StepFormType
    const currentStepRequest = useAppSelector(
        (state: RootState) =>
            currentStepId && currentAutomationId && selectStepById(state, currentStepId, currentAutomationId, 'request')
    ) as StepRequestType
    const currentStepScript = useAppSelector(
        (state: RootState) =>
            currentStepId && currentAutomationId && selectStepById(state, currentStepId, currentAutomationId, 'script')
    ) as StepScriptType
    const currentUser = useAppSelector((state: RootState) => currentUserId && selectUserById(state, currentUserId))

    useEffect(() => {
        const setup = async () => {
            dispatch(fetchAutomationsWithSteps())
            dispatch(fetchUsers())
            dispatch(fetchSteps())
            dispatch(fetchEnvironmentWithVariables())
            dispatch(fetchVariables())
            checkIfRecording()
        }
        setup()
    }, [])

    const newAutomation = () => {
        dispatch(
            addAutomation({
                name: ''
            })
        )
        dispatch(fetchAutomationsWithSteps())
    }

    const newEnvironment = () => {
        dispatch(addEnvironment({ name: '' }))
        dispatch(fetchEnvironmentWithVariables())
    }

    return (
        <div className="App">
            <Header />
            {page === PAGES.USER_ACCOUNTS && (
                <div className="user-accounts-container">
                    {users.length > 0 ? <Users users={users} /> : <div className="no-users">No users found</div>}

                    <button
                        className="button-positive-action-1"
                        onClick={() =>
                            dispatch(
                                addUser({
                                    ph_password: '',
                                    ph_dob: '',
                                    ph_first_name: '',
                                    ph_last_name: '',
                                    ph_inception_date: '',
                                    ph_email: '',
                                    ph_post_code: '',
                                    session_UUID: '',
                                    quote_ref: null,
                                    created_at: null,
                                    created_error: null
                                })
                            )
                        }>
                        {' '}
                        Add user{' '}
                    </button>
                </div>
            )}
            {page === PAGES.AUTOMATIONS && (
                <div className="automations-container">
                    {automations.length > 0 ? (
                        <Automations automations={automations} />
                    ) : (
                        <div className="no-users">No automations found</div>
                    )}
                    <button className="button-positive-action-1" onClick={() => newAutomation()}>
                        {' '}
                        Add Automation{' '}
                    </button>
                </div>
            )}
            {page === PAGES.STEP_FORM_EDIT && currentStepForm && <StepFormEdit step={currentStepForm} />}
            {page === PAGES.STEP_REQUEST_EDIT && currentStepRequest && <StepRequestEdit step={currentStepRequest} />}
            {page === PAGES.STEP_SCRIPT_EDIT && currentStepScript && <StepScriptEdit step={currentStepScript} />}
            {page === PAGES.USER_EDIT && currentUser && <UserEdit user={currentUser} />}
            {page === PAGES.ENVIRONMENTS && (
                <>
                    <Environments environments={environments} />
                    <button className="button-positive-action-1" onClick={() => newEnvironment()}>
                        {' '}
                        Add Environment{' '}
                    </button>
                </>
            )}
        </div>
    )
}

export default App