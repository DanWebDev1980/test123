/* global chrome */

function observeForElement(step, callback) {
    const observer = new MutationObserver(function () {
        const element = findElement([step])
        if (element) {
            console.log('Element found: ', element)
            observer.disconnect()
            callback(element)
        } else {
            observer.disconnect()
            // Wait for 500 milliseconds before starting the observer again
            setTimeout(() => {
                observer.observe(document, {
                    attributes: true,
                    childList: true,
                    subtree: true
                })
            }, 2000)
        }
    })

    observer.observe(document, {
        attributes: true,
        childList: true,
        subtree: true
    })
}

const waitForElement = (step) => {
    return new Promise((resolve, reject) => {
        let element = null
        element = findElement([step])
        if (element) {
            console.log('Element found: ', element)
            resolve(element)
        } else {
            console.error('Element not found', step)
            observeForElement(step, function (newElement) {
                console.log('Element has been added: ', newElement)
                resolve(newElement)
            })
        }
    })
}

function findLinkByBrand(brand) {
    console.log('findLinkByBrand')

    // Get the specific tbody by its ID
    let div = document.querySelector('#QuoteSearch\\:QuoteSearchScreen\\:SearchResultsTitle\\:QuoteSearch_ExtLV-body')

    let tbody = div.querySelector('tbody')

    // If the tbody exists, perform the search
    if (tbody) {
        // Get all the rows in the tbody
        let rows = tbody.querySelectorAll('tr')

        // Iterate over each row
        for (let row of rows) {
            // Get all the TD elements within the current row
            let tds = row.querySelectorAll('td div')

            // Iterate over each TD element
            for (let td of tds) {
                // If the TD's innerText matches the brand, search for the anchor tag in the row
                if (td.innerText === brand) {
                    // Get the anchor tag within the current row
                    let a = row.querySelector('td div a')

                    // If the anchor tag exists, simulate a click event on it
                    if (a) {
                        console.log('Found the Quote link --------------!', a)
                        return a
                    } else {
                        console.log('Could not find the Quote link')
                        return null
                    }
                }
            }
        }
    } else {
        return null
    }
}

function findElement(elementObjects) {
    console.log('findElement: ', elementObjects)
    // Iterate over each object in the array
    for (const current of elementObjects) {
        let element = null
        if (current.custom_find === 'select_quote') {
            console.log('findElement: select_quote')
            element = findLinkByBrand(current.custom_find_value)
            if (element !== null && element !== undefined) {
                console.log('Element found by select_quote: ', element)
                return element
            }
        } else {
            // Priority 1: Use ID to find the element
            element = document.getElementById(current.element_attributes?.id)
            if (element !== null && element !== undefined) {
                console.log('Element found by ID: ', element)
                return element
            }

            // Priority 2: Use XPath to find the element
            element = document.evaluate(
                current.element_x_path,
                document,
                null,
                XPathResult.FIRST_ORDERED_NODE_TYPE,
                null
            ).singleNodeValue
            if (element !== null && element !== undefined) {
                console.log('Element found by XPath: ', element)
                return element
            }
        }
    }

    // If no elements found, return null
    return null
}

function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms))
}

const performStep = async (step) => {
    if (document.readyState !== 'complete') {
        await new Promise((resolve) => (window.onload = resolve))
    }
    let element = await waitForElement(step)

    if (element) {
        console.log('Element found perform action on: ', element)
        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA' || element.tagName === 'SELECT') {
            console.log('Content Script -- performStep -- Action - Set Value on type: ', element.type)

            if (element.type === 'radio' || element.type === 'checkbox') {
                console.log('Content Script -- performStep -- Action - Set checked true')
                element.checked = true // Checks the radio or checkbox
                // Create a new 'Event' instance
                let checkedEvent = new Event('checked', {
                    bubbles: true,
                    cancelable: true
                })

                // Dispatch the checkedEvent
                await delay(3000)
                checkedEvent.stopPropagation()
            } else if (element.type === 'button') {
                console.log('Content Script -- performStep -- Action - Click')
                element.click() // Toggles the state
                // Create a new 'Event' instance
                let clickEvent = new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                })

                // Dispatch the clickEvent
                await delay(8000)
                clickEvent.stopPropagation()
            } else {
                console.log('Content Script -- performStep -- Action - Set value: ', step.element_value)

                element.value = step.element_value
                // Create a new 'Event' instance
                let inputEvent = new Event('input', {
                    bubbles: true,
                    cancelable: true
                })

                // Dispatch the inputEvent
                inputEvent.stopPropagation()
            }
        } else {
            console.log('Content Script -- performStep -- Action - Click')
            element.click()

            // Create and dispatch a 'click' event
            let clickEvent = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                view: window
            })
            await delay(8000)
            clickEvent.stopPropagation()
        }
        chrome.runtime.sendMessage({ action: 'runStepScriptFinished', success: true })
    } else {
        chrome.runtime.sendMessage({ action: 'runStepScriptFinished', success: false })
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'performStep') {
        console.log('Content Script -- performStep Listener: ', request.step)
        const step = request.step
        performStep(step)
    }
})
