/* global chrome */
console.log('runPageScript loaded')

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('runPageScript loaded')
    if (request.action === 'RUN_PAGE_SCRIPT') {
        const nameEvent = new CustomEvent('runPageScript', {
            detail: { script: request.script }
        });
        window.dispatchEvent(nameEvent);
    }
});

window.addEventListener('message', function(event) {
    // We only accept messages from ourselves
    if (event.source !== window)
        return;
    
    if (event.data.source && event.data.source === 'HDAutomation-page-script') {
        chrome.runtime.sendMessage(event.data);
    }
});
