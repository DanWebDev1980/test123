/* global chrome */
console.log('contentScript loaded')
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('contentScript loaded')
    if (request.action === 'MTA_START') {
        const nameEvent = new CustomEvent('startMTAEvent', {
            detail: { jwt: request.jwt, policyNumber: request.policyNumber }
        })
        window.dispatchEvent(nameEvent)
    }
})
