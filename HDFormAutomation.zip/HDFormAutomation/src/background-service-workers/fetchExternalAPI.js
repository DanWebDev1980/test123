/* global chrome */

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'FETCH') {
        const { url, body, headers, method } = request.data

        fetch(url, {
            method,
            headers,
            body
        })
            .then((response) => response.text())
            .then((data) => {
                sendResponse({ data, error: null })
            })
            .catch((error) => {
                console.error('error', error)
                sendResponse({ data: null, error })
            })

        return true
    }
})
