/* global chrome */

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'START_RECORDING') {
        console.log('Action - Run Record')
        let tab = request.tab
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: function () {
                function getXPath(node) {
                    if (node.id !== '') {
                        return 'id("' + node.id + '")'
                    }
                    if (node === document.body) {
                        return node.tagName
                    }

                    let count = 0
                    let sibling
                    for (sibling = node.previousSibling; sibling; sibling = sibling.previousSibling) {
                        if (sibling.nodeType === Node.DOCUMENT_TYPE_NODE) {
                            continue
                        }
                        if (sibling.nodeName === node.nodeName) {
                            count++
                        }
                    }

                    return getXPath(node.parentNode) + '/' + node.tagName + (count ? '[' + (count + 1) + ']' : '')
                }

                function getElementDetails(element) {
                    const interactiveElements = ['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA']

                    let target = element

                    // Bubble up until an interactive element or the root is reached
                    while (target && !interactiveElements.includes(target.tagName)) {
                        target = target.parentElement
                    }
                    console.log('getElementDetails -- Element Searching: ', target)
                    console.log('getElementDetails -- Target found: ', target)
                    // If no interactive parent element was found, return null
                    if (!target) {
                        return null
                    }

                    const isInteractive = interactiveElements.includes(target.tagName)
                    const hasClickListener = target.onclick != null

                    // Only proceed if the element is interactive or has a click listener
                    if (!isInteractive && !hasClickListener) {
                        return null
                    }

                    const attributes = Array.from(target.attributes).reduce((obj, attr) => {
                        obj[attr.name] = attr.value
                        return obj
                    }, {})

                    const details = Object.assign({
                        tagName: target.tagName,
                        classNames: target.className?.split(' '),
                        content: target.textContent,
                        innerText: target.innerText,
                        attributes,
                        xpath: getXPath(target)
                    })

                    return details
                }

                function handleClick(e) {
                    console.log('handleClick event click', e)
                    const elementDetails = getElementDetails(e.target)
                    saveRecordedStep(elementDetails)
                }

                function handleInput(e) {
                    const elementDetails = getElementDetails(e.target)

                    if (!elementDetails) {
                        return
                    }

                    elementDetails.value = e.target.value

                    saveRecordedStep(elementDetails)
                }

                function handleChange(e) {
                    console.log('handleChange event change', e)
                    const elementDetails = getElementDetails(e.target)

                    if (!elementDetails) {
                        return
                    }

                    elementDetails.value = e.target.value

                    saveRecordedStep(elementDetails)
                }

                function saveRecordedStep(data) {
                    // implementation of saveRecordedStep, saving steps to chrome.storage.local
                    chrome.storage.local.get({ recordedSteps: [] }, function (result) {
                        result.recordedSteps.push(data)
                        chrome.storage.local.set({
                            recordedSteps: result.recordedSteps,
                            recording: 'finished'
                        })
                    })
                }

                const createElementButton = () => {
                    let button = document.createElement('button')
                    button.innerHTML = 'Stop Recording'
                    button.style.position = 'absolute'
                    button.style.top = '100px'
                    button.style.right = '0px'
                    button.onclick = function () {
                        // Remove event listeners here
                        document.removeEventListener('click', handleClick, false)
                        document.removeEventListener('input', handleInput, false)
                        document.removeEventListener('change', handleChange, false)
                        // Remove this button
                        document.body.removeChild(button)
                    }
                    // Add the button to the body
                    document.body.appendChild(button)
                }

                document.addEventListener('click', handleClick, false)
                document.addEventListener('input', handleInput, false)
                document.addEventListener('change', handleChange, false)

                createElementButton()
            }
        })
    }
})
