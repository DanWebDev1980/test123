/* global chrome */

function listenerFunction(request, sender, sendResponse) {
    if (request.action === 'runStep') {
        let tab = request.tab
        const step = request.step
        console.log('Background Service Worker -- Run step: ', step)

        const tempListener = (message) => {
            if (message.action === 'runStepScriptFinished') {
                console.log('runStep.js -- runStepScriptFinished')
                chrome.runtime.onMessage.removeListener(tempListener)

                if (message.success) {
                    sendResponse({ success: true })
                } else {
                    sendResponse({ success: false, error: 'runStep Script execution failed' })
                }
            }
        }

        // Add the temporary listener
        chrome.runtime.onMessage.addListener(tempListener)

        chrome.scripting.executeScript(
            {
                target: { tabId: tab.id },
                files: ['dist/perform_step.bundle.js']
            },
            (results) => {
                if (chrome.runtime.lastError) {
                    // If there's an error in injecting the script
                    sendResponse({ success: false, error: chrome.runtime.lastError })
                    return // Exit to prevent further execution
                }
                // If no error, send the 'performStep' message to the script
                chrome.tabs.sendMessage(tab.id, {
                    action: 'performStep',
                    step // Ensure the 'steps' variable is defined in your code
                })
            }
        )

        return true // Indicates you wish to send a response asynchronously
    }
}

if (chrome.runtime.onMessage.hasListener(listenerFunction)) {
    chrome.runtime.onMessage.removeListener(listenerFunction)
}

chrome.runtime.onMessage.addListener(listenerFunction)
