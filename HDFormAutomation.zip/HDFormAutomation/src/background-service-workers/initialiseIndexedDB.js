/* global chrome */
import { IndexedDBHDAutomations } from '../constants/app'

chrome.runtime.onInstalled.addListener(() => {
    let openRequest = indexedDB.open(IndexedDBHDAutomations, 1)

    openRequest.onupgradeneeded = function (e) {
        let db = openRequest.result

        if (!db.objectStoreNames.contains('automation')) {
            db.createObjectStore('automation', {
                keyPath: 'id',
                autoIncrement: true
            })
        }

        if (!db.objectStoreNames.contains('step_form')) {
            db.createObjectStore('step_form', { keyPath: 'id', autoIncrement: true })
        }
        if (!db.objectStoreNames.contains('step_request')) {
            db.createObjectStore('step_request', { keyPath: 'id', autoIncrement: true })
        }
        if (!db.objectStoreNames.contains('step_script')) {
            db.createObjectStore('step_script', { keyPath: 'id', autoIncrement: true })
        }

        if (!db.objectStoreNames.contains('user')) {
            db.createObjectStore('user', { keyPath: 'id', autoIncrement: true })
        }

        if (!db.objectStoreNames.contains('environment')) {
            let environmentStore = db.createObjectStore('environment', {
                keyPath: 'id',
                autoIncrement: true
            })
            environmentStore.createIndex('name', 'name', { unique: false })
        }

        if (!db.objectStoreNames.contains('variable')) {
            let variableStore = db.createObjectStore('variable', {
                keyPath: 'id',
                autoIncrement: true
            })
            variableStore.createIndex('name', 'name', { unique: false })
            variableStore.createIndex('value', 'value', { unique: false })
        }

        if (!db.objectStoreNames.contains('automation_step')) {
            let automationStepsStore = db.createObjectStore('automation_step', {
                keyPath: 'id',
                autoIncrement: true
            })
            automationStepsStore.createIndex('automation_id', 'automation_id', {
                unique: false
            })
            automationStepsStore.createIndex('step_id', 'step_id', { unique: false })
            automationStepsStore.createIndex('step_order', 'step_order', {
                unique: false
            })
        }

        if (!db.objectStoreNames.contains('environment_variable')) {
            let environmentVariableStore = db.createObjectStore('environment_variable', {
                keyPath: 'id',
                autoIncrement: true
            })
            environmentVariableStore.createIndex('environment_id', 'environment_id', {
                unique: false
            })
            environmentVariableStore.createIndex('variable_id', 'variable_id', {
                unique: false
            })
        }

        if (!db.objectStoreNames.contains('user_automation_step')) {
            let userAutomationsStore = db.createObjectStore('user_automation_step', {
                keyPath: 'id',
                autoIncrement: true
            })
            userAutomationsStore.createIndex('user_id', 'user_id', { unique: false })
            userAutomationsStore.createIndex('automation_id', 'automation_id', {
                unique: false
            })
            userAutomationsStore.createIndex('step_id', 'step_id', { unique: false })
            userAutomationsStore.createIndex('step_type', 'step_type', { unique: false })
        }
    }

    openRequest.onsuccess = function (e) {
        console.log('Database initialized successfully')
    }

    openRequest.onerror = function (e) {
        console.error('Error initializing database', openRequest.error)
    }
})
