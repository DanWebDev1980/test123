# HD Automation

The purpose of this application is to automate manual tasks whilst developing and testing HD applications.

## Features

- [x] Environment variables for different environments and applications
- [x] User Accounts for attaching automations for specific users
- [x] Import and export automations to share with other users and backup
- [x] Create automations and edit steps
- [x] Fill values with data from the database
- [] Add specific automations to specific users to create a more realistic scenario
- [] Custom automations can be added by developers where the record function is not suitable
- [] Record form filling to store as an automation for later use


### Tasks that are complete are marked with a checkbox.

