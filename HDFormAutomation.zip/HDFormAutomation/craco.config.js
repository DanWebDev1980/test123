const path = require("path");

module.exports = {
  webpack: {
    configure: (webpackConfig, { env, paths }) => {
      webpackConfig.mode = "development";
      webpackConfig.entry = {
        main: paths.appIndexJs,
        background: [
          path.resolve(
            __dirname,
            "src/background-service-workers/initialiseIndexedDB.js"
          ),
          path.resolve(__dirname, "src/background-service-workers/runStep.js"),
          path.resolve(
            __dirname,
            "src/background-service-workers/runRecord.js"
          ),
          path.resolve(
            __dirname,
            "src/background-service-workers/fetchExternalAPI.js"
          ),
        ],
        perform_step: [
          path.resolve(__dirname, "src/content-scripts/performStep.js"),
        ],
        start_mta: [
          path.resolve(__dirname, "src/content-scripts/mta/startMTAEvent.js"),
        ],
        run_page_script: [
          path.resolve(__dirname, "src/content-scripts/mta/runPageScript.js"),
        ],
      };

      webpackConfig.module = {
        rules: [
          {
            test: /\.(js|jsx|tsx|ts)$/,
            exclude: /(node_modules|bower_components)/,
            use: {
              loader: "babel-loader",
              options: {
                presets: [
                  "@babel/preset-env",
                  [
                    "@babel/preset-react",
                    {
                      runtime: "automatic",
                    },
                  ],
                  "@babel/preset-typescript", // if you're using TypeScript
                ],
              },
            },
          },
          // Adding this section to handle CSS files
          {
            test: /\.css$/,
            use: [
              "style-loader", // creates style nodes from JS strings
              "css-loader", // translates CSS into CommonJS
            ],
          },
          {
            test: /\.(png|jpe?g|gif)$/i,
            loader: "file-loader",
            options: {
              name: "[path][name].[ext]",
              outputPath: "images",
              publicPath: "images",
              emitFile: true,
              esModule: false,
            },
          },
        ],
      };

      webpackConfig.output.filename = (chunkData) => {
        return chunkData.chunk.name === "main"
          ? "static/js/[name].[contenthash:8].js"
          : "dist/[name].bundle.js";
      };

      return webpackConfig;
    },
  },
};
